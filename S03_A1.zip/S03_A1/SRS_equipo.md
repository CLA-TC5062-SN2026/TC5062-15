# Especificación de Requisitos de Software (SRS)

## Audio2Score

**Versión:** 2.0 consolidada  
**Fecha:** 2026-10-01  
**Estado:** Prototipo funcional V1  
**Proyecto:** Audio2Score

---

# 1. Introducción

## 1.1 Propósito del documento

Este documento define los requisitos del sistema Audio2Score, una aplicación web orientada a apoyar a músicos, estudiantes, compositores y docentes en la obtención de una transcripción musical inicial a partir de una grabación de audio.

El SRS consolidado integra el mejor de los trabajos individuales del equipo. Su objetivo es establecer el alcance del prototipo, las funciones principales del sistema, las restricciones del proyecto, los requisitos funcionales, no funcionales y de dominio, así como los criterios de aceptación que validarán el producto.

## 1.2 Alcance del sistema

Audio2Score permitirá a un usuario autenticado crear proyectos, cargar archivos de audio, validar su contenido, iniciar explícitamente el procesamiento, consultar el estado del trabajo, revisar una propuesta inicial de transcripción musical y descargar sus resultados en formatos MIDI y PDF.

El sistema conservará la información del proyecto, el audio original, sus metadatos y los resultados generados para permitir su consulta posterior. La transcripción será un borrador útil para revisión humana y no sustituirá el criterio musical del usuario.

El prototipo tendrá una duración de desarrollo de 12 semanas y estará orientado a grabaciones con melodía principal claramente identificable, en un contexto de música popular o acústica con voz, guitarra, piano y, a veces, bajo y percusión.

## 1.3 Definiciones y acrónimos

- Audio2Score: aplicación web objeto de esta especificación.
- SRS: Especificación de Requisitos de Software.
- RF: Requerimiento funcional.
- RNF: Requerimiento no funcional.
- RD: Requerimiento de dominio.
- MIDI: formato digital para intercambiar información musical.
- PDF: formato para compartir la partitura en documento portable.
- Proyecto: unidad que relaciona un usuario con un audio, su estado y sus resultados.
- Transcripción inicial: propuesta automática de representación musical generada a partir del audio y sujeta a revisión.
- Usuario autenticado: persona que ha iniciado sesión y puede operar sobre sus propios proyectos.

## 1.4 Referencias

Este documento integra aportes de los cuatro SRS individuales realizados por el equipo y se basa en la estructura recomendada por IEEE 830 para especificaciones de requisitos.

---

# 2. Descripción general

## 2.1 Perspectiva del producto

Audio2Score será una aplicación web compuesta por:

1. Frontend: registro, inicio/cierre de sesión, creación y consulta de proyectos, carga de audio, consulta del estado, visualización de resultados y descarga.
2. Backend: gestión de usuarios, archivos, proyectos, autenticación y comunicación con el motor de transcripción.
3. Base de datos: almacenamiento de usuarios, proyectos, archivos, metadatos y resultados.

El flujo principal será:

audio → validación → procesamiento → transcripción inicial → visualización → revisión → MIDI/PDF

El prototipo puede apoyarse en herramientas existentes de reconocimiento musical y procesamiento de audio, sin requerir desarrollar un modelo desde cero.

## 2.2 Funciones del producto

Las funciones principales del sistema son:

- Registrar usuarios.
- Autenticar usuarios.
- Crear proyectos de transcripción.
- Cargar archivos de audio.
- Validar formato, tamaño y duración del archivo.
- Iniciar explícitamente el procesamiento.
- Consultar el estado del procesamiento.
- Generar una transcripción inicial.
- Visualizar la partitura generada.
- Revisar y corregir la transcripción.
- Comparar audio y transcripción.
- Identificar fragmentos o notas con menor confianza.
- Descargar resultados en MIDI y PDF.
- Consultar historial y resultados de proyectos.
- Reintentar procesamientos fallidos.
- Eliminar o archivar proyectos.

## 2.3 Características del usuario

Los usuarios previstos son principalmente:

- músicos,
- estudiantes de música,
- compositores,
- docentes.

Estos usuarios no requieren conocimientos avanzados de procesamiento de audio para operar la herramienta. Deben poder interpretar una representación musical y decidir si la transcripción generada requiere corrección.

## 2.4 Restricciones

- El prototipo debe desarrollarse en un plazo máximo de 12 semanas.
- Se soportarán inicialmente archivos en formato MP3 y WAV.
- El tamaño máximo por archivo será de 100 MB.
- La duración máxima por archivo será de 15 minutos.
- El sistema estará orientado a grabaciones con melodía principal claramente identificable.
- La transcripción no es necesariamente definitiva ni totalmente precisa para material complejo o polifónico.
- Cada usuario únicamente podrá operar sobre sus propios proyectos, archivos y resultados.
- No se exige construir desde cero un modelo de inteligencia artificial; se pueden reutilizar herramientas existentes.
- El sistema debe mantener mensajes claros y comprensibles para usuarios no técnicos.

## 2.5 Suposiciones y dependencias

- Se asume que el equipo tiene acceso a un motor de reconocimiento musical que pueda procesar archivos de audio compatibles.
- Se asume que cada usuario contará con una cuenta válida para acceder al sistema.
- Se asume que los archivos de audio estarán protegidos por permisos del usuario y no serán reutilizados sin autorización.
- Se asume que el prototipo estará desplegado como aplicación web accesible desde navegador.

---

# 3. Requisitos específicos

## 3.1 Requerimientos funcionales

### RF-01 — Registro e inicio de sesión

El sistema deberá permitir que un usuario cree una cuenta y luego inicie sesión con credenciales válidas.

- RF-01-AC-1: Dado que una persona no posee cuenta, cuando completa el formulario de registro con datos válidos, entonces el sistema crea la cuenta y permite el acceso para iniciar sesión.
- RF-01-AC-2: Dado que existe una cuenta registrada, cuando el usuario presenta credenciales válidas, entonces el sistema autentica al usuario y autoriza su acceso.
- RF-01-AC-3: Dado que una persona intenta iniciar sesión con credenciales inválidas, cuando envía el formulario, entonces el sistema rechaza el acceso y muestra un mensaje de autenticación fallida.
- RF-01-AC-4: Dado que el usuario tiene una sesión autenticada, cuando solicita cerrar sesión, entonces el sistema invalida la sesión y el usuario deja de estar autenticado.

### RF-02 — Creación y gestión de proyectos

El sistema deberá permitir crear un proyecto de transcripción y asociarlo al usuario autenticado.

- RF-02-AC-1: Dado que el usuario ha iniciado sesión, cuando solicita crear un proyecto, entonces el sistema registra el proyecto y lo asocia a su cuenta.
- RF-02-AC-2: Dado que el proyecto ha sido creado correctamente, cuando el usuario consulta su listado de proyectos, entonces el proyecto aparece con sus metadatos básicos.
- RF-02-AC-3: Dado que el usuario proporciona datos incompletos o inválidos, cuando intenta crear el proyecto, entonces el sistema rechaza la operación y le indica qué corregir.

### RF-03 — Carga de archivos de audio

El sistema deberá permitir al usuario autenticado cargar un archivo de audio dentro de un proyecto.

- RF-03-AC-1: Dado que el usuario está autenticado y el proyecto existe, cuando selecciona y carga un archivo MP3 o WAV válido, entonces el sistema acepta el archivo y lo asocia al proyecto.
- RF-03-AC-2: Dado que el usuario intenta cargar un archivo cuyo formato o contenido no es compatible, cuando finaliza la carga, entonces el sistema rechaza el archivo y explica la causa.
- RF-03-AC-3: Dado que el usuario intenta cargar un archivo protegido o ilegible, cuando se intenta procesarlo, entonces el sistema lo rechaza y reporta que no puede ser leído o procesado.

### RF-04 — Validación de archivo antes del procesamiento

El sistema deberá validar las condiciones del archivo antes de iniciar la transcripción.

- RF-04-AC-1: Dado que el usuario intenta cargar un archivo con duración superior a 15 minutos, cuando se valida, entonces el sistema rechaza la carga y comunica el límite excedido.
- RF-04-AC-2: Dado que el usuario intenta cargar un archivo superior a 100 MB, cuando se valida, entonces el sistema rechaza el archivo y comunica que excede el tamaño permitido.
- RF-04-AC-3: Dado que el archivo cumple los formatos y límites definidos, cuando se carga al proyecto, entonces el sistema lo acepta y lo deja listo para procesamiento.

### RF-05 — Inicio explícito del procesamiento

El sistema deberá permitir que el usuario inicie el procesamiento del audio asociado a un proyecto.

- RF-05-AC-1: Dado que el proyecto contiene un archivo válido, cuando el usuario solicita iniciar el procesamiento, entonces el sistema pone el proyecto en estado "procesando".
- RF-05-AC-2: Dado que el procesamiento no puede iniciarse, cuando el sistema detecta un error de validación o de disponibilidad, entonces informa al usuario y no inicia la tarea.

### RF-06 — Estado del procesamiento

El sistema deberá mantener y mostrar el estado del procesamiento del proyecto.

- RF-06-AC-1: Dado que existe un proyecto con audio asociado, cuando el usuario consulta el proyecto, entonces el sistema debe mostrar su estado como pendiente, procesando, completado o fallido.
- RF-06-AC-2: Dado que el procesamiento ha finalizado, cuando el usuario revisa el proyecto, entonces el sistema muestra el resultado disponible o el motivo del fallo.

### RF-07 — Generación de transcripción inicial

El sistema deberá generar una propuesta inicial de transcripción a partir del audio procesado.

- RF-07-AC-1: Dado que un proyecto tiene un archivo de audio válido, cuando el procesamiento finaliza correctamente, entonces el sistema genera una transcripción inicial asociada al proyecto.
- RF-07-AC-2: Dado que la transcripción se genera, cuando se presenta al usuario, entonces incluye la altura, el ritmo y la duración de las notas detectadas de la melodía principal.
- RF-07-AC-3: Dado que el sistema no puede determinar un elemento musical con seguridad, cuando presenta la transcripción, entonces se marca como estimado o no determinado, sin presentarlo como cierta.

### RF-08 — Visualización de la partitura

El sistema deberá permitir ver la transcripción como una partitura generada automáticamente.

- RF-08-AC-1: Dado que existe una transcripción completada, cuando el usuario abre el proyecto, entonces el sistema muestra la representación de la partitura.
- RF-08-AC-2: Dado que la partitura es generada automáticamente, cuando se visualiza, entonces el sistema informa que puede requerir revisión y corrección humana.

### RF-09 — Revisión y corrección de la transcripción

El sistema deberá permitir al usuario revisar y corregir la transcripción inicial.

- RF-09-AC-1: Dado que el usuario abre una transcripción disponible, cuando modifica la salida y guarda, entonces el sistema actualiza la versión vigente del resultado.
- RF-09-AC-2: Dado que el usuario vuelve a abrir el proyecto, cuando consulta la transcripción, entonces el sistema presenta la versión guardada más reciente.

### RF-10 — Comparación entre audio y transcripción y baja confianza

El sistema deberá facilitar la revisión de la transcripción comparándola con el audio original e identificando elementos con menor confianza.

- RF-10-AC-1: Dado que el usuario selecciona una transcripción, cuando consulta el detalle, entonces el sistema permite visualizar el audio y la transcripción de forma conjunta.
- RF-10-AC-2: Dado que hay notas o fragmentos con detección poco confiable, cuando se presenta la transcripción, entonces el sistema marca esos elementos como de baja confianza.

### RF-11 — Descarga en MIDI

El sistema deberá permitir descargar la transcripción en formato MIDI.

- RF-11-AC-1: Dado que existe una transcripción generada, cuando el usuario solicita descargar MIDI, entonces el sistema entrega un archivo MIDI con la versión más reciente.
- RF-11-AC-2: Dado que el proyecto incluye compases, tempo o duraciones disponibles, cuando exporta MIDI, entonces el archivo conserva la información musical disponible.

### RF-12 — Descarga en PDF

El sistema deberá permitir descargar la partitura en formato PDF.

- RF-12-AC-1: Dado que la partitura está disponible, cuando el usuario solicita descargar PDF, entonces el sistema genera un documento legible con nombre del proyecto y fecha de generación.
- RF-12-AC-2: Dado que la salida es una transcripción automática, cuando el PDF se genera, entonces incluye la indicación de que corresponde a un borrador y puede requerir revisión.

### RF-13 — Consulta del historial y detalle del proyecto

El sistema deberá permitir consultar el detalle de cada proyecto y revisar resultados previos.

- RF-13-AC-1: Dado que el usuario tiene proyectos registrados, cuando abre su listado, entonces puede consultar cada proyecto y sus metadatos.
- RF-13-AC-2: Dado que el proyecto tiene resultados previos, cuando el usuario revisa el historial, entonces el sistema permite visualizar los intentos anteriores sin sobrescribir el más reciente.
- RF-13-AC-3: Dado que el usuario desea renombrar un proyecto, cuando confirma el cambio, entonces el sistema actualiza el nombre asociado al proyecto.

### RF-14 — Reintento de procesamiento y manejo de fallos

El sistema deberá permitir reintentar el procesamiento y conservar el motivo del fallo.

- RF-14-AC-1: Dado que un procesamiento falló, cuando el usuario revisa el detalle del proyecto, entonces el sistema muestra el motivo del error si está disponible.
- RF-14-AC-2: Dado que el resultado inicial no es satisfactorio, cuando el usuario solicita nuevo procesamiento, entonces el sistema permite un nuevo intento con una configuración sensible o alternativa.

### RF-15 — Eliminación y archivado de proyectos

El sistema deberá permitir eliminar o archivar proyectos de forma segura y confirmada.

- RF-15-AC-1: Dado que el usuario selecciona un proyecto propio para eliminar, cuando confirma la acción, entonces el sistema elimina el proyecto, el audio y los resultados asociados de la aplicación.
- RF-15-AC-2: Dado que el usuario archiva un proyecto, cuando accede a la vista principal, entonces el proyecto queda oculto de la lista activa pero permanece protegido en el sistema de acuerdo con la política del prototipo.

### RF-16 — Resumen de la transcripción

El sistema deberá mostrar un resumen útil del resultado generado.

- RF-16-AC-1: Dado que existe una transcripción generada, cuando el usuario accede al detalle, entonces el sistema muestra indicadores como número de notas detectadas, cobertura estimada, tempo estimado y tonalidad estimada, cuando estén disponibles.
- RF-16-AC-2: Dado que un valor es estimado y no definitivo, cuando se presenta en el resumen, entonces el sistema lo identifica como estimación.

## 3.2 Requerimientos no funcionales

### RNF-01 — Rendimiento
Para un archivo de audio de aproximadamente tres minutos, el objetivo de procesamiento debe ser de tres minutos o menos. La métrica debe confirmarse usando un entorno y archivo de referencia acordados.

### RNF-02 — Seguridad y control de acceso
El acceso a proyectos, archivos y resultados debe restringirse al usuario propietario autenticado. Consulta, edición, descarga y eliminación deben verificar la propiedad del recurso.

### RNF-03 — Usabilidad
La aplicación debe poder operar desde un navegador sin requerir instalación ni configuración especializada. Los mensajes y etiquetas deben ser claros para usuarios sin conocimientos técnicos.

### RNF-04 — Robustez y disponibilidad del flujo
El sistema deberá mostrar estados claros de pendiente, procesamiento, completado y fallo, además de permitir reintentos y recuperación ante errores de procesamiento.

### RNF-05 — Privacidad y retención
El sistema deberá informar al usuario el periodo de conservación de sus grabaciones y transcripciones y debe proteger la información contra acceso no autorizado.

### RNF-06 — Compatibilidad de entrada
La aplicación debe aceptar archivos MP3 y WAV como mínimo, y la validación debe informar claramente si se exceden límites de tamaño, duración o contenido.

## 3.3 Requerimientos de dominio

### RD-01 — Naturaleza del resultado
La transcripción generada por Audio2Score es una propuesta inicial de apoyo y no sustituye la revisión, corrección ni criterio musical de una persona.

### RD-02 — Dominio musical del prototipo
El sistema está orientado principalmente a grabaciones con melodía principal claramente identificable, en contextos de música pop, acústica, voz, guitarra, piano y, en ocasiones, bajo y percusión.

### RD-03 — Duración típica de uso
Las grabaciones esperadas suelen durar entre 1 y 5 minutos. Este rango define el uso principal del prototipo y no constituye un límite técnico obligatorio para todo tipo de archivo.

### RD-04 — Protección de materiales de terceros
Los archivos de audio y sus transcripciones no deben reutilizarse, compartirse ni usarse para otros fines sin autorización del usuario y con respeto a los derechos de autor.

## 3.4 Decisiones pendientes y elementos de validación

Los siguientes aspectos requieren definición o validación con la parte interesada antes de cierre del diseño final:

- Si el procesamiento iniciará automáticamente tras la carga o después de una acción explícita del usuario.
- Si cada carga crea un proyecto nuevo o puede agregarse a uno existente.
- Si se ampliará la compatibilidad de formatos más allá de MP3 y WAV.
- Qué conjunto de audios de referencia se usará para medir precisión.
- Cómo se definirá la “baja confianza” de una nota o fragmento.
- Cuál será la política exacta de retención y eliminación de archivos.

---

# 4. Matriz de trazabilidad (resumen)

| ID | Requisito principal |
|---|---|
| RF-01 | Registro e inicio de sesión |
| RF-02 | Crear proyecto |
| RF-03 | Cargar archivo |
| RF-04 | Validar archivo |
| RF-05 | Iniciar procesamiento |
| RF-06 | Consultar estado |
| RF-07 | Generar transcripción |
| RF-08 | Visualizar partitura |
| RF-09 | Revisar/corregir transcripción |
| RF-10 | Comparar audio/transcripción |
| RF-11 | Descargar MIDI |
| RF-12 | Descargar PDF |
| RF-13 | Historial y detalle del proyecto |
| RF-14 | Reintentos y fallos |
| RF-15 | Eliminar/archivar proyecto |
| RF-16 | Resumen de transcripción |

---

# 5. Criterios de aceptación del prototipo

Se consideran aceptados para la entrega del prototipo cuando:

1. Un usuario puede registrarse, iniciar sesión y cerrar sesión sin errores.
2. Un usuario autenticado puede crear un proyecto y cargar un audio compatible.
3. El sistema valida correctamente formato, tamaño y duración del archivo.
4. El usuario puede iniciar el procesamiento y consultar el resultado final o el error.
5. El sistema presenta la partitura y permite revisar, exportar y consultar resultados.
6. La seguridad de acceso por usuario propietario se cumple de manera consistente.
7. El sistema cumple con los objetivos de rendimiento y usabilidad declarados para el prototipo.

