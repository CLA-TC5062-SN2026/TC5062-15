# Especificación de Requisitos de Software (SRS)

## Audio2Score

**Versión:** 1.0 inicial  
**Fecha:** 2026-09-25  
**Estado:** Borrador para revisión

## 1. Introducción

### 1.1 Propósito del documento

Este documento especifica los requisitos iniciales de Audio2Score para orientar el diseño, desarrollo y validación del prototipo. Está dirigido al equipo de desarrollo, al product owner y a las partes interesadas que validarán el alcance y los criterios de aceptación.

### 1.2 Alcance del sistema

Audio2Score será una aplicación web para ayudar a músicos, estudiantes, compositores y docentes a convertir grabaciones de audio en una transcripción musical inicial. El usuario podrá cargar audio, obtener y consultar una propuesta de partitura, corregirla y descargar resultados MIDI y PDF.

El prototipo busca reducir el tiempo necesario para iniciar una transcripción. No pretende sustituir la revisión ni el criterio musical de una persona. Su desarrollo está previsto dentro de un periodo de 12 semanas.

### 1.3 Definiciones y acrónimos

- **Audio2Score:** Aplicación web descrita en esta especificación.
- **Transcripción inicial:** Representación musical generada automáticamente a partir de audio, destinada a servir como borrador editable y sujeto a revisión.
- **MIDI:** Musical Instrument Digital Interface; formato de intercambio de información musical.
- **PDF:** Portable Document Format; formato de documento para visualizar o compartir la partitura.
- **RF:** Requerimiento funcional.
- **RNF:** Requerimiento no funcional.
- **RD:** Requerimiento de dominio.

## 2. Descripción general

### 2.1 Perspectiva del producto

Audio2Score es un nuevo sistema web compuesto por:

- Un frontend para registro, inicio de sesión, carga de audio, consulta de proyectos y visualización de resultados.
- Un backend para administrar usuarios, archivos y procesamiento, y comunicarse con el motor de transcripción.
- Una base de datos para almacenar usuarios, proyectos, metadatos y transcripciones.


### 2.2 Funciones del producto

Las funciones principales previstas son:

- Registrar e iniciar sesión para acceder a la aplicación.
- Cargar grabaciones de audio y generar una transcripción musical inicial.
- Consultar el estado del procesamiento y los resultados.
- Visualizar y corregir la partitura generada.
- Descargar los resultados en MIDI y PDF.
- Consultar y eliminar proyectos propios.

### 2.3 Características del usuario

Los usuarios previstos son músicos, estudiantes, compositores y docentes. Pueden tener distintos niveles de conocimientos musicales y técnicos. La interfaz debe poder utilizarse desde un navegador sin exigir la instalación o configuración de herramientas musicales especializadas.

### 2.4 Restricciones

- El prototipo debe desarrollarse dentro del plazo de 12 semanas.
- La transcripción depende de la complejidad y calidad del material de audio; el resultado es una propuesta inicial y puede requerir corrección humana.
- El sistema debe apoyarse en herramientas existentes de procesamiento y reconocimiento musical, según la arquitectura propuesta.
- Cada usuario debe poder acceder únicamente a sus propios proyectos.
- Los archivos de audio pueden contener material de terceros o protegido por derechos de autor; su uso debe respetar los permisos correspondientes.
- Los formatos y límites de tamaño de archivo, la política de retención y el nivel de disponibilidad todavía requieren definición por las partes interesadas.

## 3. Requerimientos específicos

### 3.1 Requerimientos funcionales (con criterios de aceptación)

- **RF-01: Registro e inicio de sesión.** El sistema debe permitir que un usuario cree una cuenta e inicie sesión.
  - **RF-01-AC-1:**
    - **Dado que** una persona aún no tiene una cuenta y proporciona los datos requeridos,
    - **cuando** envía el formulario de registro,
    - **entonces** el sistema crea la cuenta y confirma que el registro se completó.
  - **RF-01-AC-2:**
    - **Dado que** existe una cuenta registrada,
    - **cuando** el usuario envía credenciales válidas en el formulario de inicio de sesión,
    - **entonces** el sistema autentica al usuario y concede acceso a su cuenta.
  - **RF-01-AC-3:**
    - **Dado que** existe una cuenta registrada,
    - **cuando** una persona envía credenciales inválidas en el formulario de inicio de sesión,
    - **entonces** el sistema deniega el acceso y muestra un mensaje de autenticación fallida.

- **RF-02: Carga de audio.** El sistema debe permitir al usuario cargar archivos de audio WAV y MP3.
  - **RF-02-AC-1:**
    - **Dado que** el usuario ha iniciado sesión y dispone de un archivo WAV o MP3,
    - **cuando** selecciona y carga el archivo,
    - **entonces** el sistema acepta el archivo para procesamiento; si el archivo no es aceptable, informa al usuario y no inicia su procesamiento.

- **RF-03: Creación de proyecto.** El sistema debe asociar la grabación cargada y sus resultados con un proyecto del usuario.
  - **RF-03-AC-1:**
    - **Dado que** un usuario autenticado ha cargado un archivo de audio aceptado,
    - **cuando** el sistema registra la carga,
    - **entonces** crea o actualiza un proyecto asociado a ese usuario y lo muestra en su lista de proyectos.

- **RF-04: Generación de transcripción.** El sistema debe procesar el audio cargado y generar una transcripción musical inicial.
  - **RF-04-AC-1:**
    - **Dado que** un proyecto contiene un archivo de audio aceptado,
    - **cuando** el usuario solicita su procesamiento y este finaliza correctamente,
    - **entonces** el sistema guarda una transcripción inicial en el proyecto y muestra que el procesamiento se completó.

- **RF-05: Contenido musical de la transcripción.** La transcripción debe representar las alturas y el ritmo de la melodía principal e incluir duraciones, tempo y compases cuando puedan determinarse del audio.
  - **RF-05-AC-1:**
    - **Dado que** el sistema ha generado una transcripción a partir de un audio,
    - **cuando** presenta el resultado,
    - **entonces** incluye las alturas y el ritmo identificados de la melodía principal, además de duraciones, tempo y compases cuando hayan podido determinarse, y no presenta como determinados los elementos que no pudo establecer.

- **RF-06: Visualización de partitura.** El sistema debe mostrar en pantalla la partitura generada.
  - **RF-06-AC-1:**
    - **Dado que** el usuario tiene acceso a un proyecto con una transcripción completada,
    - **cuando** abre el resultado,
    - **entonces** el sistema muestra en pantalla la representación de la partitura.

- **RF-07: Revisión y corrección.** El sistema debe permitir al usuario revisar y corregir la transcripción inicial.
  - **RF-07-AC-1:**
    - **Dado que** el usuario abre una transcripción disponible en uno de sus proyectos,
    - **cuando** modifica la transcripción y guarda los cambios,
    - **entonces** el sistema guarda la corrección como la versión vigente del resultado y presenta esa versión al volver a abrir el proyecto.

- **RF-08: Exportación MIDI.** El sistema debe permitir descargar la transcripción en formato MIDI.
  - **RF-08-AC-1:**
    - **Dado que** el usuario tiene acceso a un proyecto con una transcripción guardada,
    - **cuando** selecciona la opción de descarga MIDI,
    - **entonces** el sistema entrega un archivo MIDI correspondiente a la versión guardada más reciente de la transcripción del proyecto.

- **RF-09: Exportación PDF.** El sistema debe permitir descargar la partitura en formato PDF.
  - **RF-09-AC-1:**
    - **Dado que** el usuario tiene acceso a un proyecto con una partitura guardada,
    - **cuando** selecciona la opción de descarga PDF,
    - **entonces** el sistema entrega un archivo PDF que contiene la partitura correspondiente a la versión guardada más reciente del proyecto.

- **RF-10: Estado del procesamiento.** Durante el procesamiento, el sistema debe informar que el trabajo sigue activo y proporcionar una estimación del tiempo restante.
  - **RF-10-AC-1:**
    - **Dado que** hay un trabajo de transcripción en curso,
    - **cuando** el usuario consulta su estado,
    - **entonces** el sistema indica que el trabajo sigue activo y muestra una estimación del tiempo restante; al finalizar o fallar, actualiza el estado correspondiente.

- **RF-11: Comunicación de fallos.** Si el procesamiento falla, el sistema debe informar qué ocurrió y cómo puede continuar el usuario.
  - **RF-11-AC-1:**
    - **Dado que** el procesamiento de un archivo no pudo completarse,
    - **cuando** el sistema registra el fallo y muestra el estado del trabajo,
    - **entonces** informa que el procesamiento falló y presenta una explicación y una acción siguiente comprensibles para el usuario.

- **RF-12: Consulta de proyectos.** El sistema debe permitir al usuario consultar su lista de proyectos y abrir los resultados de transcripción disponibles.
  - **RF-12-AC-1:**
    - **Dado que** un usuario ha iniciado sesión y tiene proyectos registrados,
    - **cuando** abre su lista de proyectos y selecciona uno,
    - **entonces** el sistema muestra sus proyectos y el resultado disponible del proyecto seleccionado, sin mostrar ni permitir el acceso a proyectos de otros usuarios.

- **RF-13: Eliminación de proyecto.** El sistema debe permitir al usuario eliminar un proyecto, la grabación cargada y los resultados asociados almacenados en la aplicación.
  - **RF-13-AC-1:**
    - **Dado que** el usuario ha seleccionado un proyecto propio para eliminar,
    - **cuando** confirma la eliminación,
    - **entonces** el proyecto deja de aparecer en su lista y la grabación cargada y los resultados asociados dejan de estar disponibles desde la aplicación.

### 3.2 Requerimientos no funcionales

- **RNF-01 (Rendimiento):** Para un archivo de audio de aproximadamente tres minutos, el tiempo objetivo para generar la transcripción inicial es de tres minutos o menos. Esta meta debe confirmarse y medirse durante las pruebas de aceptación con un entorno y archivo de referencia acordados.
- **RNF-02 (Seguridad):** El acceso a proyectos, grabaciones y transcripciones debe estar restringido al usuario propietario autenticado. Las operaciones de consulta, descarga, edición y eliminación deben verificar la propiedad del recurso.
- **RNF-03 (Usabilidad):** La carga y consulta de proyectos debe poder realizarse desde un navegador, sin que el usuario instale o configure programas especializados.
- **RNF-04 (Usabilidad):** Los mensajes de estado y error deben ser comprensibles para usuarios sin conocimientos técnicos y deben distinguir claramente entre procesamiento activo, resultado completado y fallo.
- **RNF-05 (Privacidad y transparencia):** El sistema debe informar al usuario cuánto tiempo se conservarán sus grabaciones y transcripciones. El plazo concreto debe definirse antes de la liberación del prototipo.

No se establece en las fuentes un objetivo cuantitativo de disponibilidad o escalabilidad. Esos atributos quedan pendientes de decisión y no se consideran criterios de aceptación en esta versión.

### 3.3 Requerimientos de dominio

- **RD-01:** El resultado de Audio2Score es una transcripción inicial de apoyo; no sustituye completamente el trabajo de transcripción, revisión y corrección de un músico.
- **RD-02:** El dominio de uso previsto incluye música pop y piezas acústicas con voz, guitarra, piano y, en ocasiones, bajo y percusión.
- **RD-03:** Las grabaciones descritas habitualmente duran entre uno y cinco minutos. Este intervalo caracteriza el uso esperado y no establece por sí mismo un límite técnico de duración aceptada.
- **RD-04:** Las grabaciones pueden contener material de terceros o protegido por derechos de autor. El sistema no debe reutilizar grabaciones ni transcripciones para otros fines sin autorización del usuario.

### 3.4 Decisiones pendientes de definición

Los siguientes puntos requieren decisión del product owner y validación con las partes interesadas. No se consideran criterios de aceptación aprobados hasta que se incorporen valores o reglas definitivas:

- **Inicio del procesamiento:** RF-02 permite cargar un archivo para procesamiento, mientras RF-04 indica que el usuario solicita el procesamiento; el alcance de `proyecto_base.md` describe generación automática. Debe definirse si el procesamiento comienza automáticamente tras la carga o después de una acción explícita del usuario.
- **Creación de proyectos:** RF-03 indica que el sistema crea o actualiza un proyecto, pero falta definir si cada carga genera un proyecto nuevo o si puede agregarse a uno existente.
- **Límites de carga:** definir tamaño máximo, duración admitida, parámetros técnicos de audio admitidos y tratamiento de archivos dañados o con extensión/formato no coincidente.
- **Precisión musical:** definir un conjunto de audios de referencia, método de comparación y umbrales de aceptación para alturas, ritmo y otros elementos musicales.
- **Edición de transcripciones:** definir qué atributos musicales puede modificar el usuario y cómo se confirma o guarda cada cambio.
- **Rendimiento:** definir archivo y entorno de prueba, condiciones de carga y los instantes exactos que delimitan la medición del objetivo de tres minutos de RNF-01.
- **Retención y eliminación:** definir el periodo de conservación y si la eliminación de un proyecto también elimina copias de respaldo, además de retirarlo de la aplicación.
- **Disponibilidad y escalabilidad:** establecer si existen objetivos cuantitativos para estos atributos y, de ser así, sus métricas y condiciones de medición.
- **Herramientas de procesamiento:** confirmar si el uso de herramientas existentes de procesamiento y reconocimiento musical es una restricción técnica obligatoria o solo una opción de implementación; la sección 2.4 actual y el historial de revisión no coinciden en este punto.