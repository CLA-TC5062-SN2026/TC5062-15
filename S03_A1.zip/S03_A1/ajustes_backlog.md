# Ajustes realizados al backlog

# Notas
El agente tuvo la tendencia de dar a casi todo prioridades altas y bajos story points, lo cual fueron las mayorias de las modificaciones.

## Objetivo

Este documento registra los cambios sugeridos al backlog inicial para alinear la estimación de esfuerzo con la experiencia práctica del equipo y el desempeño esperado del prototipo.

## Cambios aplicados

### 1. Historia 1
- Story Points: de 3 -> 5
- Justificación: la creación de cuenta y flujo de autenticación involucra varios validaciones, mensajes de error, persistencia y acceso seguro. Por experiencia personal, esto tarda mas de lo planeado.

### 2. Historia 2
- Story Points: de 2 -> 3
- Justificación: el inicio y cierre de sesión son partes critics de seguridad, entonces suelen requerir mas tiempo para validad que no hayan vulnerabilidades o sesiones que se quedaron abiertas.

### 3. Historia 4
- Story Points: de 3 -> 5
- Justificación: la creación de proyectos probablemente incluya prueba y error, por lo tanto de seguro tomara mas tiempo.

### 4. Historia 6
- Story Points: de 3 -> 2
- Prioridad: de Media -> Baja
- Justificación: la validación de archivos es importante, pero no la mas critica.

### 5. Historia 7
- Prioridad: de Alta -> Media
- Justificación: el inicio de procesamiento es importante, pero los cambiso de estados no deben ser la prioridad máxima.

### 6. Historia 8
- Cambio: se elimina la opción de “pendiente” por ahora.
- Justificación: en la práctica el estado del proyecto se vuelve más claro cuando se trabaja solo con “procesando”, “completado” y “fallido”. Esto reduce complejidad.

### 7. Historia 9
- Cambio en descripción: se ajustó a: “la marca como estimado o fallido (no se pudo interpretar)”.
- Justificación: esta redacción refleja mejor la realidad del análisis musical: el sistema no siempre puede reconocer un elemento correctamente.

### 8. Historia 11
- Prioridad: Media -> Baja
- Justificación: la identificación de baja confianza es valiosa para revisión humana, pero no es un bloque crítico para la primera entrega funcional.
