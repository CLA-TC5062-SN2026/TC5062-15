# Backlog completo del proyecto Audio2Score

## Épica 1: Autenticación y acceso al sistema

### Historia 1
Como usuario nuevo, quiero crear una cuenta con correo y contraseña, para acceder a la aplicación y guardar mis proyectos.

- Criterios de aceptación:
  - Dado que el usuario completa el formulario con datos válidos, cuando envía el registro, entonces el sistema crea la cuenta.
  - Dado que el usuario intenta registrar datos incompletos o inválidos, cuando envía el formulario, entonces el sistema rechaza el registro y muestra el error.
- Story Points: 5
- Prioridad: Alta

### Historia 2
Como usuario registrado, quiero iniciar sesión y cerrar sesión, para acceder de forma segura a mis proyectos y salir cuando termine.

- Criterios de aceptación:
  - Dado que el usuario ingresa credenciales válidas, cuando intenta iniciar sesión, entonces el sistema lo autentica y le permite entrar.
  - Dado que el usuario tiene una sesión activa, cuando solicita cerrar sesión, entonces el sistema finaliza la sesión y requiere autenticación para seguir.
- Story Points: 3
- Prioridad: Alta

### Historia 3
Como usuario autenticado, quiero consultar solo mis proyectos y resultados, para asegurar que mis archivos y transcripciones permanecen privados.

- Criterios de aceptación:
  - Dado que el usuario ha iniciado sesión, cuando consulta su panel de proyectos, entonces solo ve sus proyectos asociados.
  - Dado que el usuario intenta acceder a un proyecto ajeno, cuando solicita abrirlo, entonces el sistema bloquea la operación.
- Story Points: 5
- Prioridad: Alta

---

## Épica 2: Administración de proyectos y archivos

### Historia 4
Como usuario autenticado, quiero crear un proyecto de transcripción, para organizar mi audio y sus resultados.

- Criterios de aceptación:
  - Dado que el usuario ha iniciado sesión, cuando crea un proyecto, entonces el sistema lo registra asociado a su cuenta.
  - Dado que el proyecto se crea correctamente, cuando el usuario revisa su lista, entonces aparece con sus metadatos básicos.
- Story Points: 5
- Prioridad: Alta

### Historia 5
Como usuario autenticado, quiero cargar un archivo de audio válido dentro de un proyecto, para generar una transcripción inicial.

- Criterios de aceptación:
  - Dado que el usuario selecciona un archivo MP3 o WAV compatible, cuando lo carga, entonces el sistema lo acepta y lo asocia al proyecto.
  - Dado que el archivo no cumple con el formato o las reglas del prototipo, cuando intenta cargarlo, entonces el sistema rechaza la operación y explica el motivo.
- Story Points: 5
- Prioridad: Alta

### Historia 6
Como usuario, quiero recibir mensajes claros cuando el archivo no cumple reglas de tamaño, duración o formato, para corregir el problema antes de procesar.

- Criterios de aceptación:
  - Dado que el archivo supera el tamaño máximo o la duración permitida, cuando se valida, entonces el sistema muestra el error específico.
  - Dado que el archivo es válido, cuando se carga, entonces el sistema no muestra errores de validación.
- Story Points: 2
- Prioridad: Baja

---

## Épica 3: Procesamiento automático y visualización de resultados

### Historia 7
Como usuario autenticado, quiero iniciar explícitamente el procesamiento de un audio, para generar la transcripción musical inicial.

- Criterios de aceptación:
  - Dado que el proyecto tiene un archivo válido, cuando el usuario pulsa “procesar”, entonces el sistema cambia el estado a “procesando”.
  - Dado que no puede iniciar el procesamiento, cuando ocurre un error de validación o disponibilidad, entonces el sistema informa al usuario y no deja el proyecto en estado inválido.
- Story Points: 5
- Prioridad: Media

### Historia 8
Como usuario, quiero consultar el estado del procesamiento, para saber si mi proyecto está en curso, completado o fallido.

- Criterios de aceptación:
  - Dado que el proyecto tiene un trabajo asociado, cuando el usuario revisa el proyecto, entonces el sistema muestra su estado actual.
  - Dado que el procesamiento termina o falla, cuando el usuario consulta el proyecto, entonces el sistema refleja el resultado correspondiente.
- Story Points: 3
- Prioridad: Alta

### Historia 9
Como usuario, quiero obtener una transcripción inicial con altura, ritmo y duración de las notas, para contar con un primer borrador musical útil.

- Criterios de aceptación:
  - Dado que el procesamiento finaliza correctamente, cuando se genera el resultado, entonces la transcripción incluye notas, ritmo y duración detectados.
  - Dado que el sistema no puede determinar un valor con certeza, cuando presenta la transcripción, entonces la marca como estimado o fallido (no se pudo interpretar).
- Story Points: 8
- Prioridad: Alta

---

## Épica 4: Revisión, exportación y gestión del resultado

### Historia 10
Como usuario, quiero visualizar la partitura generada y compararla con el audio original, para revisar y corregir la transcripción.

- Criterios de aceptación:
  - Dado que existe una transcripción completada, cuando el usuario abre el proyecto, entonces el sistema muestra la partitura.
  - Dado que el usuario consulta la transcripción, cuando revisa el resultado, entonces puede comparar el audio con la salida generada.
- Story Points: 8
- Prioridad: Alta

### Historia 11
Como usuario, quiero identificar notas o fragmentos de baja confianza, para revisar con criterio los elementos que requieren validación manual.

- Criterios de aceptación:
  - Dado que la transcripción incluye elementos poco confiables, cuando se presenta al usuario, entonces el sistema los marca explícitamente.
  - Dado que el usuario revisa la transcripción, cuando selecciona un segmento marcado, entonces visualiza la indicación de baja confianza.
- Story Points: 5
- Prioridad: Baja

### Historia 12
Como usuario, quiero exportar mi transcripción en MIDI y PDF, para compartirla, conservarla o trabajar con ella fuera de la plataforma.

- Criterios de aceptación:
  - Dado que existe una transcripción válida, cuando el usuario solicita exportar MIDI, entonces el sistema genera y entrega el archivo.
  - Dado que existe una partitura generada, cuando el usuario solicita exportar PDF, entonces el sistema genera el documento con nombre y fecha.
- Story Points: 5
- Prioridad: Alta

---

# Resumen del backlog

- Total de historias: 12
- Prioridad Alta: 8
- Prioridad Media: 1
- Prioridad Baja: 3
- Story Points totales: 61

## Priorización sugerida por entrega

### Sprint 1
- Autenticación y acceso
- Creación de proyectos
- Carga y validación de archivos
- Inicio y estado del procesamiento

### Sprint 2
- Generación de transcripción
- Visualización y revisión
- Baja confianza y resumen
- Exportación MIDI/PDF

### Sprint 3
- Mejoras de historial, reintentos y eliminación/archivo
- Ajustes de UX y validación final
