# Diferencias entre los SRS individuales y resolución mediante votación

## 1. Objetivo

Este documento identifica qué aportó cada SRS individual al SRS consolidado y cómo se resolvieron los conflictos de alcance, definición técnica y prioridad funcional.

## 2. Método de votación utilizado

Para seleccionar la propuesta más adecuada se aplicó un método de votación ponderada basado en tres criterios:

1. Impacto en el usuario y valor del negocio.
2. Frecuencia con la que el requisito apareció en los documentos individuales.
3. Riesgo de no incluirlo: si el requisito era necesario para el funcionamiento del prototipo o para la calidad del producto.

Cada requisito se evaluó con una escala de 1 a 5 por cada criterio. La opción con mayor puntaje total y con presencia en al menos 2 de los 4 documentos fue priorizada. Cuando hubo conflicto entre dos alternativas técnicas o de alcance, se eligió la propuesta con mayor puntuación, y en caso de empate se priorizó la versión más conservadora y aplicable al prototipo de 12 semanas.

### Regla aplicada

- Requisito con presencia en 3 o 4 documentos: se incorpora automáticamente al SRS consolidado.
- Requisito con presencia en 2 documentos: se incorpora si tiene impacto alto o valor estratégico.
- Requisito presente en 1 documento: se incorpora solo si mejora significativamente la experiencia de usuario o la calidad del prototipo.

## 3. Aporte de cada SRS individual

### 3.1 Aporte de Adrian

El documento de Adrian aportó una base sólida en:

- estructura formal del SRS,
- alcance del sistema,
- definición de usuarios y restricciones,
- requisitos funcionales con criterios de aceptación formales,
- requerimientos no funcionales y de dominio,
- aclaración de decisiones pendientes.

Su contribución clave fue dejar el SRS con una redacción más completa y con una buena separación entre funcionales, no funcionales y de dominio. También destacó de forma muy útil la necesidad de resolver decisiones pendientes, especialmente sobre inicio del procesamiento, creación de proyectos y métricas de rendimiento.

### 3.2 Aporte de Daniel

El documento de Daniel aportó una visión más orientada al MVP y a la viabilidad técnica del prototipo. Su valor principal fue:

- definición del flujo funcional del producto,
- límites concretos de carga de audio,
- validación técnica del archivo,
- enfoque en transcripción musical con melodía principal,
- criterios más realistas para un prototipo funcional.

Además, incorporó requisitos como:

- resumen de la transcripción,
- comparación entre audio y transcripción,
- evaluación de baja confianza,
- capacidades de historial y reintento del procesamiento.

### 3.3 Aporte de Ivan

El documento de Ivan aportó una especificación más técnica y detallada sobre la operación del sistema. Su principal contribución fue:

- definición de límites de tamaño y duración,
- claridad sobre el procesamiento como actividad explícita del usuario,
- restricción de acceso por usuario,
- enfoque en materiales de complejidad limitada,
- importancia del ritmo como elemento obligatorio y del tempo como capacidad deseable.

También planteó reglas de validación más concretas para que el equipo pueda implementar un prototipo con mayor consistencia.

### 3.4 Aporte de Rigo

El documento de Rigo aportó la visión más completa y operativa del producto. Su valor principal fue:

- mayor nivel de detalle funcional,
- mejor definición del historial de proyectos,
- manejo de fallos y reintentos,
- requisitos de seguridad y privacidad,
- funcionalidades avanzadas como edición, archivado, comparación, resumen y control de información.

Es el documento con mayor riqueza en requisitos no funcionales y en manejo de operaciones reales del sistema. Por ello fue una de las bases más importantes para el SRS consolidado.

## 4. Conflictos detectados y cómo se resolvieron

### 4.1 Conflicto: formatos y límites de carga

Los SRS individuales no coincidían en:

- formatos permitidos,
- duración máxima por archivo,
- tamaño máximo por archivo.

#### Solución por votación

Se priorizó la propuesta que equilibraba viabilidad técnica y flexibilidad del prototipo:

- formato: MP3 y WAV
- duración máxima: 15 minutos
- tamaño máximo: 100 MB

Esta decisión ganó porque fue la más equilibrada entre los documentos con mayor detalle y porque se ajusta mejor a un prototipo de 12 semanas sin limitar demasiado al usuario.

### 4.2 Conflicto: inicio del procesamiento

Algunos documentos asumían un inicio automático tras cargar el archivo; otros exigían una acción explícita del usuario.

#### Solución por votación

Se decidió que el usuario debe iniciar explícitamente el procesamiento. Esta opción recibió mayor puntaje porque:

- ofrece control al usuario,
- reduce procesamiento innecesario,
- es más clara en términos de manejo de errores,
- coincide con la claridad del enfoque de desarrollo del prototipo.

### 4.3 Conflicto: alcance funcional extra

Se identificaron requisitos más avanzados como:

- cierre de sesión en todos los dispositivos,
- recuperación/cambio de contraseña,
- comparación detallada entre audio y transcripción,
- identificación de baja confianza,
- resumen de notas,
- archivado de proyectos,
- control de espacio utilizado.

#### Solución por votación

Se incorporaron los requisitos con más valor para el prototipo, pero se mantuvieron como parte del alcance del prototipo funcional y no como ampliaciones irreales. Se priorizaron aquellos que mejor apoyan la revisión humana y la utilidad del producto sin aumentar excesivamente la complejidad de implementación.

### 4.4 Conflicto: profundidad de requisitos no funcionales

Algunos documentos eran más ligeros en seguridad, privacidad y retención, mientras otros eran más exigentes.

#### Solución por votación

Se integraron los requisitos no funcionales más robustos pero manteniendo el enfoque MVP. Esto significa:

- control de acceso por propietario,
- mensajes claros,
- retención informada al usuario,
- manejo de errores y reintentos,
- compatibilidad básica,
- pero sin ampliar el alcance a escalabilidad masiva ni infraestructura de producción.

## 5. Resultado final del consenso

Se consolidó una versión final del proyecto con estas reglas principales:

- sistema web con autenticación y gestión de proyectos,
- carga y validación de archivos,
- procesamiento explícito por parte del usuario,
- transcripción inicial con altura, ritmo y duración,
- presentación visual y exportación a MIDI/PDF,
- revisión humana y baja confianza,
- historial y manejo de fallos,
- eliminación con confirmación,
- control de acceso por usuario,
- enfoque prototipo realista y viable.

## 6. Conclusión

El SRS consolidado refleja el mejor de cada contribución individual: la estructura formal de Adrian, la visión de MVP de Daniel, la precisión técnica de Ivan y la profundidad operativa de Rigo. La resolución de conflictos se hizo con criterio de votación y priorización, buscando mantener un prototipo útil, viable y consistente con las necesidades del equipo.
