# Definition of Done (DoD) — Audio2Score

Una historia de usuario se considera **Done** únicamente cuando cumple todos los criterios aplicables siguientes. Los criterios específicos de aceptación de la historia también deben estar satisfechos; esta DoD no los reemplaza.

## Criterios de finalización

### Requisitos y comportamiento

- La implementación cumple los criterios de aceptación acordados para la historia.
- Los flujos principales se pueden completar de principio a fin en la aplicación.
- Los errores esperados se comunican claramente y no dejan datos ni estados inconsistentes.
- Para funcionalidades de audio, el sistema valida el formato, tamaño y duración definidos para el prototipo antes de procesar, e informa el motivo cuando rechaza un archivo.
- Para procesamiento, se puede distinguir entre los estados en curso, completado y fallido; un fallo no se presenta como un resultado exitoso.
- Para transcripciones, notas o fragmentos que el sistema no pueda determinar con certeza se marcan como estimados o no interpretables, según los criterios de la historia.

### Calidad técnica y pruebas

- Se han probado los escenarios de aceptación principales, incluidos los errores y rechazos expresamente requeridos por la historia.
- No quedan defectos conocidos que impidan completar el flujo principal o comprometan la privacidad de los datos.

### Seguridad y privacidad

- Las operaciones que requieren autenticación la exigen; las operaciones de proyectos limitan lectura y modificación a su propietario.
- Los datos de audio, proyectos y transcripciones solo se exponen a usuarios autorizados.
- La validación de entradas se realiza en el servidor además de cualquier validación de interfaz necesaria.

### Interfaz y accesibilidad básica

- La interfaz permite completar la acción prevista con etiquetas, instrucciones y mensajes de resultado comprensibles.
- Los estados de carga, ausencia de datos, éxito y error se muestran cuando correspondan.

### Mantenibilidad y entrega

- El código sigue las convenciones del proyecto y no introduce dependencias innecesarias.
- La documentación de uso, configuración o decisiones se actualiza cuando el cambio la afecta.
- Las migraciones, configuraciones o pasos de instalación necesarios están incluidos y descritos.
- La funcionalidad se ha verificado en el entorno de desarrollo o pruebas previsto y puede demostrarse al equipo o responsable del producto.

## Cierre de historia

Antes de marcar una historia como Done, el responsable confirma sus criterios de aceptación y los puntos aplicables de esta DoD. Si algún criterio no aplica, debe ser evidente por el alcance de la historia; no se omiten criterios para ocultar trabajo pendiente.
