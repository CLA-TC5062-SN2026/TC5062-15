# Planificación del Sprint 1

## Sprint Goal

**Al finalizar el Sprint 1, un usuario podrá registrarse, iniciar y cerrar sesión, crear proyectos de transcripción y consultar únicamente los proyectos asociados a su cuenta; el sistema impedirá el acceso a proyectos de otros usuarios.**

El objetivo entrega una base funcional y segura para que los siguientes sprints incorporen carga de audio y procesamiento sin exponer proyectos entre cuentas.

## Historias seleccionadas

| Historia | Descripción | Prioridad | Story Points |
|---|---|---:|---:|
| 1 | Crear una cuenta con correo y contraseña | Alta | 5 |
| 2 | Iniciar sesión y cerrar sesión | Alta | 3 |
| 3 | Consultar solo los proyectos y resultados propios | Alta | 5 |
| 4 | Crear un proyecto de transcripción asociado a la cuenta | Alta | 5 |
| **Total comprometido** | | | **18 SP** |

### Justificación

- Las cuatro historias tienen prioridad alta y corresponden al alcance inicial que el backlog sugiere para el Sprint 1: autenticación, acceso y creación de proyectos.
- Las historias 1 y 2 habilitan el acceso a la aplicación; la historia 4 permite organizar el trabajo del usuario.
- La historia 3 se incluye junto con la creación de proyectos para que el primer resultado no permita consultar proyectos ajenos. Es parte necesaria de una entrega utilizable y coherente con la privacidad descrita en el backlog.
- Se posponen la carga y validación de audio (historias 5 y 6), así como el inicio y seguimiento del procesamiento (historias 7 y 8). Incorporarlas elevaría el alcance a 33 SP en total para el conjunto sugerido del Sprint 1 y ampliaría el objetivo más allá de esta primera base segura.

## Capacidad estimada

- **Tiempo disponible:** 2 semanas × 8–9 horas por semana = **16–18 horas de equipo** en total.
- **Capacidad de planificación provisional:** **18 SP**.
- **Compromiso propuesto:** **18 SP** (historias 1–4).

El backlog no proporciona velocidad histórica, cantidad de integrantes ni una relación calibrada entre horas disponibles y story points. Por eso, los 18 SP son una estimación provisional para planificar este primer sprint, no una conversión directa de horas a puntos ni una velocidad comprobada. Se debe revisar la capacidad con la velocidad real observada al cierre del sprint. El cálculo de horas supone que las 8–9 horas semanales corresponden al equipo completo; si son por integrante, la capacidad deberá recalcularse según el tamaño del equipo.

## Criterios de logro del Sprint Goal

Al cierre del sprint se comprobará que:

1. Un usuario puede crear una cuenta con datos válidos y recibe un error claro si los datos son incompletos o inválidos.
2. Un usuario registrado puede iniciar sesión con credenciales válidas y cerrar sesión.
3. Un usuario autenticado puede crear un proyecto que queda asociado a su cuenta y aparece en su lista.
4. Al consultar proyectos, cada usuario solo ve los propios; un intento de abrir un proyecto ajeno se bloquea.

Las historias se considerarán terminadas cuando cumplan sus criterios de aceptación del backlog.
