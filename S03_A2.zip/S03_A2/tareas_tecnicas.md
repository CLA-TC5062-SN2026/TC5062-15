# Tareas técnicas — Sprint 1

Estimaciones en horas de trabajo efectivo. Cada tarea tiene una duración máxima de 4 horas y está asignada a Adrián Valdés con el rol correspondiente. Se incluyen solo las tareas necesarias para cumplir los criterios de aceptación y el aislamiento entre cuentas; los casos límite adicionales se difieren.

## Historia 1 — Crear una cuenta (5 SP)

| Tarea | Estimación | Responsable | Criterio de terminado |
|---|---:|---|---|
| Definir el modelo de usuario y la migración para correo único y almacenamiento seguro de credenciales | 1.5 h | Adrián Valdés (backend dev) | La migración se aplica correctamente y el esquema impide guardar dos cuentas con el mismo correo. |
| Implementar el endpoint de registro con validación de campos y almacenamiento de contraseña con hash | 2 h | Adrián Valdés (backend dev) | Datos válidos crean la cuenta; entradas inválidas se rechazan con un error comprensible; la contraseña no se almacena en texto plano. |
| Crear el formulario de registro y mostrar confirmación o errores del servidor | 1.5 h | Adrián Valdés (frontend dev) | El formulario permite enviar correo y contraseña y presenta el resultado de la operación sin perder los errores de validación. |
| Probar registro válido y rechazo de datos incompletos o inválidos | 1 h | Adrián Valdés (QA) | Las pruebas automatizadas verifican la creación con datos válidos y el rechazo requerido por los criterios de aceptación. |
| **Subtotal** | **6 h** | | |

## Historia 2 — Iniciar y cerrar sesión (3 SP)

| Tarea | Estimación | Responsable | Criterio de terminado |
|---|---:|---|---|
| Implementar inicio y cierre de sesión usando el mecanismo de sesión establecido por el proyecto | 1.5 h | Adrián Valdés (backend dev) | Credenciales válidas crean una sesión y cerrar sesión la invalida. |
| Crear las vistas y acciones de inicio y cierre de sesión | 1.5 h | Adrián Valdés (frontend dev) | Se puede enviar el formulario de acceso y cerrar la sesión desde la interfaz. |
| Probar inicio de sesión válido y cierre efectivo de sesión | 1 h | Adrián Valdés (QA) | La prueba automatizada confirma que las credenciales válidas abren una sesión y que, tras cerrarla, se requiere autenticación para continuar. |
| **Subtotal** | **4 h** | | |

## Historia 3 — Consultar únicamente proyectos propios (5 SP)

| Tarea | Estimación | Responsable | Criterio de terminado |
|---|---:|---|---|
| Restringir consultas de lista y detalle de proyectos al usuario autenticado | 1.5 h | Adrián Valdés (backend dev) | La lista devuelve solo proyectos del usuario y la consulta de un proyecto ajeno queda bloqueada sin revelar sus datos. |
| Implementar la vista de proyectos y su estado vacío | 1.5 h | Adrián Valdés (frontend dev) | La vista muestra los proyectos devueltos para la cuenta actual y un mensaje claro si aún no hay proyectos. |
| Probar aislamiento entre dos cuentas y acceso a identificador ajeno | 1 h | Adrián Valdés (QA) | Las pruebas con dos usuarios confirman que cada cuenta solo lista y abre sus propios proyectos; el acceso cruzado falla. |
| **Subtotal** | **4 h** | | |

## Historia 4 — Crear un proyecto asociado a la cuenta (5 SP)

| Tarea | Estimación | Responsable | Criterio de terminado |
|---|---:|---|---|
| Implementar la operación de creación de proyecto y asociarla al usuario autenticado | 1 h | Adrián Valdés (backend dev) | Una solicitud válida crea un proyecto con el usuario actual como propietario; una solicitud sin sesión se rechaza. |
| Crear el formulario de proyecto e integrar su resultado con la lista | 1 h | Adrián Valdés (frontend dev) | Al enviar un nombre válido, la interfaz confirma la creación y muestra el proyecto en la lista. |
| Probar creación válida y asociación correcta del propietario | 0.5 h | Adrián Valdés (QA) | La prueba automatizada confirma que el proyecto creado pertenece al usuario autenticado y aparece en su lista. |
| **Subtotal** | **2.5 h** | | |

**Esfuerzo técnico estimado: 16.5 horas** (6 + 4 + 4 + 2.5). Ninguna tarea excede 2 horas en esta estimación.

Se difieren casos límite no incluidos expresamente en los criterios de aceptación, como pruebas específicas de inicio de sesión con credenciales incorrectas y validaciones adicionales de creación de proyectos. Se mantienen el rechazo de registro incompleto o inválido y el bloqueo de acceso a proyectos ajenos porque sí son requisitos explícitos del backlog.
