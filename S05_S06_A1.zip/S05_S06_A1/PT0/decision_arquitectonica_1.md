# ADR-001: Selección del estilo arquitectónico

**Fecha:** 2026-10-06
**Estado:** Aceptado

## Contexto

Audio2Score es un prototipo de 12 semanas desarrollado por un único desarrollador que permite a un usuario autenticado cargar
un audio, procesarlo para generar una transcripción musical inicial, revisarla y descargarla en
MIDI/PDF.

Los requerimientos no funcionales imponen presiones concretas sobre la arquitectura:

- **RNF-01 (rendimiento):** un audio de ~3 minutos debe procesarse en ≤3 minutos. Ejecutar esta
  tarea dentro del ciclo de una petición HTTP arriesga timeouts y bloquea al resto de usuarios.
- **RNF-04 (robustez del flujo):** el sistema debe exponer y mantener estados explícitos
  (pendiente, procesando, completado, fallido) y permitir reintentos (RF-05, RF-06, RF-14). Esto
  presupone una ejecución **asíncrona** del procesamiento, desacoplada de la petición que lo inicia.
- **RNF-02 / RNF-05 (seguridad y privacidad):** el control de acceso por propietario debe aplicarse
  de forma consistente sobre proyectos, archivos y resultados.
- **RNF-03 / RNF-06 (usabilidad y validación):** no imponen restricciones arquitectónicas fuertes,
  son principalmente responsabilidad de la capa de API/UI.
- **Restricción de equipo:** un solo desarrollador con ~16-18 h disponibles por sprint. Cualquier estilo que exija orquestar
  múltiples servicios, infraestructura distribuida o pipelines de despliegue independientes no es
  viable en el plazo y con la capacidad del equipo.

El problema a resolver es: ¿qué estilo arquitectónico permite cumplir RNF-01 y RNF-04 (tareas de
procesamiento largas con estado y reintentos) sin exceder la complejidad operativa que un solo
desarrollador puede sostener en 12 semanas?

## Decisión

Se adopta un monolito modular en capas, con el procesamiento de audio ejecutado de forma
asíncrona mediante una cola de trabajos.

La aplicación se despliega como una sola unidad, organizada en capas (API/presentación → lógica de
negocio → acceso a datos) y, dentro de la capa de negocio, en módulos por dominio: autenticación,
proyectos, archivos de audio, procesamiento/transcripción y exportación. La operación de "iniciar
procesamiento" encola un trabajo (p. ej. con Redis + BullMQ/RQ/Celery, según el lenguaje de
implementación) que un worker ejecuta en segundo plano; al finalizar, actualiza el estado del
proyecto (`procesando` → `completado`/`fallido`) y persiste la transcripción resultante.

## Alternativas consideradas

| Alternativa | Escalabilidad | Mantenibilidad | Complejidad de implementación | Adecuación al equipo (1 dev, 12 semanas) |
|---|---|---|---|---|
| **A. Monolito en capas 100% síncrono** (el procesamiento ocurre dentro de la misma petición HTTP) | Baja: el procesamiento compite por los mismos recursos que las peticiones web y no escala por separado. | Alta: todo el código vive en un solo lugar, fácil de razonar. | Muy baja. | Buena a corto plazo, pero **no satisface RNF-04**: no hay forma natural de exponer un estado real "procesando" ni de reintentar sin bloquear al usuario. |
| **B. Monolito modular en capas + cola de trabajos asíncrona** | Media-alta: el worker se puede escalar o moverse a otro proceso/contenedor sin tocar el resto del sistema. | Alta: módulos separados por dominio dentro de un único repositorio y despliegue. | Media: agrega una cola y un worker, pero son piezas estándar y bien documentadas. | Alta: viable para un desarrollador en 12 semanas y modela directamente los estados de RF-06 y los reintentos de RF-14. |
| **C. Microservicios** (auth-service, project-service, audio-processing-service, etc., comunicados por HTTP/eventos) | Muy alta en teoría, pero irrelevante para el tráfico esperado de un prototipo. | Baja para un equipo de una persona: cada servicio requiere su propio versionado, pruebas y despliegue. | Alta: orquestación, descubrimiento de servicios, consistencia entre servicios. | Muy baja: sobreingeniería frente al alcance y el plazo del proyecto. |

Se decidio la opcion B, (Monolito modular en capas + cola de trabajos asíncrona).
## Consecuencias

**Ventajas:**
- El estado del procesamiento (RF-06) y los reintentos (RF-14) se modelan de forma natural como
  trabajos en una cola, sin necesidad de hilos bloqueantes ni de infraestructura distribuida.
- Un único despliegue y una única base de código reducen la carga operativa para un desarrollador
  solo, cumpliendo con la capacidad de equipo estimada en el Sprint 1.
- El control de acceso por propietario (RNF-02) se implementa en un solo lugar (capa de negocio),
  reduciendo el riesgo de inconsistencias entre módulos.
- La separación en módulos por dominio dentro del monolito deja una ruta de evolución clara: si en
  el futuro el procesamiento de audio necesita escalar de forma independiente, el worker ya está
  desacoplado y puede extraerse como servicio aparte sin rediseñar el resto del sistema.

**Desventajas / riesgos aceptados:**
- Se introduce una dependencia operativa adicional (broker de cola, p. ej. Redis) que no existiría
  en la alternativa A, lo que exige configurarla también en el entorno de desarrollo local.
- El monolito, al crecer, puede volverse más difícil de mantener que servicios pequeños e
  independientes; se mitiga exigiendo límites claros entre módulos (auth, proyectos, audio,
  procesamiento, exportación) desde el diseño de componentes.
- Si el volumen de procesamiento creciera significativamente más allá del alcance del prototipo,
  esta arquitectura requeriría evolucionar (por ejemplo, extrayendo el worker como servicio
  independiente); se acepta este riesgo porque está fuera del alcance de las 12 semanas.
