# ADR-001: Selección del estilo arquitectónico

**Fecha:** 2026-10-11  
**Estado:** Aceptado  
**Proyecto:** Audio2Score

## Contexto

Audio2Score es un prototipo web de 12 semanas, desarrollado por una persona, que permite cargar un audio MP3 o WAV y obtener una transcripción musical que el usuario puede revisar, editar y exportar a MIDI o PDF. El sistema conserva proyectos, audios y resultados hasta que el usuario solicite eliminarlos.

Los requisitos no funcionales que influyen en la decisión son:

- **RNF-01, rendimiento:** procesar un audio de aproximadamente tres minutos en tres minutos o menos en un entorno de prueba documentado.
- **RNF-02, seguridad:** acceso solo al propietario autenticado para consulta, edición, descarga y eliminación.
- **RNF-04, continuidad del flujo:** estados de procesamiento claros, reintentos y recuperación de fallos.
- **RNF-05, privacidad y retención:** proteger audios y transcripciones, conservarlos hasta eliminación explícita e incluir los respaldos en la política de borrado.
- **RNF-06, compatibilidad:** admitir MP3 y WAV.

El procesamiento puede durar más que una petición HTTP y fallar independientemente de la interfaz. El plazo corto y un desarrollador hacen costoso operar servicios distribuidos separados. Además, no se ha autorizado enviar audio a un motor de terceros.

## Decisión

Adoptar una arquitectura **cliente-servidor** con una SPA y una API REST implementada como **monolito modular por capas**, complementada por una cola durable y un worker de procesamiento asíncrono.

La API autenticará a los usuarios y autorizará cada operación consultando el propietario del recurso. El módulo de identidad y acceso será interno al backend. La elección concreta entre sesión segura o token queda pendiente de una decisión de implementación; no se requiere LDAP salvo que se apruebe una integración institucional/SSO.

El motor de transcripción se ejecutará localmente dentro del worker como librería o proceso empaquetado, detrás del puerto `MotorTranscripcion`. No se representa como servicio de terceros. La API registrará el intento y un mensaje de outbox en una única transacción de base de datos; un publicador entregará el trabajo a la cola. El worker consumirá el mensaje por *pull*, usando el ID del intento como ID idempotente. El estado, el lease/heartbeat y los reintentos permitirán recuperar trabajos atascados.

El worker persistirá la transcripción estructurada y sus notas. La SPA renderizará y editará la partitura a partir de esos datos. La API generará MIDI y PDF bajo demanda a partir de la versión vigente y verificará propiedad antes de autorizar cada descarga.

La política de respaldos y eliminación se documentará junto con RNF-05: la eliminación solicitada deberá alcanzar datos primarios y respaldos conforme al ciclo de retención definido. El SRS no fija proveedor, periodo de retención de copias ni plazo de purga; estos parámetros quedan explícitamente pendientes y no se inventan en este ADR.

## Alternativas consideradas

| Alternativa | Escalabilidad | Mantenibilidad | Complejidad de implementación y operación | Adecuación a un desarrollador |
|---|---|---|---|---|
| **Monolito modular por capas + worker asíncrono (seleccionada)** | Media; los workers escalan independientemente. | Alta para el alcance si se respetan límites de módulos. | Baja-media; incorpora cola, outbox, idempotencia y recuperación, sin operar muchos servicios de negocio. | Alta; un código base y un flujo de despliegue sencillo. |
| **Microservicios orientados a eventos** | Alta, con escalado y despliegue por servicio. | Puede ser alta con equipos y dominios estables; aumenta coordinación para una persona. | Alta; contratos, despliegues múltiples, observabilidad distribuida y consistencia eventual. | Baja para el plazo y equipo actuales. |
| **Aplicación por capas sin worker/cola** | Baja-media para trabajos largos. | Simple al principio; mezcla peticiones web con procesamiento y recuperación. | Baja inicialmente, pero más propensa a timeouts y estados atascados. | Media; no se ajusta bien a RNF-01 y RF-06/RF-14. |

## Consecuencias

### Positivas

- La interfaz no queda bloqueada por la transcripción y puede consultar estados persistentes.
- Outbox transaccional evita perder un trabajo entre el commit del estado y la publicación en la cola.
- Reintentos, leases y heartbeat permiten detectar y recuperar procesamiento interrumpido.
- El audio no sale del límite de confianza del sistema para ser procesado por terceros.
- Las exportaciones se derivan de una versión vigente y la API aplica autorización de propietario.
- Un worker separado conserva una vía de escalado sin introducir microservicios de negocio.

### Costos, riesgos y pendientes

- Outbox, publicación, deduplicación, leases y reintentos requieren implementación y observabilidad.
- El mecanismo de credenciales (sesión o token) está pendiente; ambas opciones deben usar transporte seguro y controles contra robo/reutilización.
- El motor local y su versión/configuración pueden limitar rendimiento; se registrarán por intento y se medirán bajo el entorno acordado (RNF-01).
- La política de respaldo debe definir proveedor, retención de copias y plazo de purga para cumplir RNF-05; estos valores siguen pendientes de decisión.
- El almacenamiento de audio y exportaciones debe soportar borrado por proyecto, incluidas copias y derivados.

## Criterios para revisar

Revisar este ADR si se autoriza un motor externo, cambian el equipo o plazo, el worker no alcanza RNF-01, se requieren despliegues independientes, o se elige proveedor/política de respaldos que modifique el modelo de privacidad.

## Fuentes

- `SRS_equipo_corregido_final.md`, versión 7.0, 2026-10-10.
- `proyecto_base.md`.
