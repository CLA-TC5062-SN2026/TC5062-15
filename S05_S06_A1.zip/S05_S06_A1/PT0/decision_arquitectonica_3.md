# Decisiones de diseño y trazabilidad — Audio2Score

**Proyecto:** Audio2Score  
**Actividad:** S04-A2 — Diseño de API RESTful (OpenAPI)  
**Documento:** `decisiones_y_trazabilidad.md`  
**Especificación base:** `openapi.yaml` (OpenAPI 3.0.3; contrato versión 1.0.0)  
**Referencia funcional:** SRS 2.0 aprobado, 11 de octubre de 2026  

## Sección A. Trazabilidad de la especificación y los criterios de aceptación

### A.1. Alcance de la revisión

Se contrastaron los 29 criterios Given–When–Then de los 13 requerimientos funcionales (RF-01 a RF-13) del SRS 2.0 contra las operaciones definidas en `openapi.yaml`. El contrato contiene 13 operaciones HTTP distribuidas en 11 rutas, organizadas mediante ocho grupos de recursos.

**Criterio de cobertura:** «Directa (API)» significa que una operación expone el comportamiento requerido; «Compartida» significa que su cumplimiento también requiere lógica de frontend, trabajador musical o almacenamiento. «Fuera de API (frontend)» identifica una interacción de interfaz sin endpoint específico. Estas clasificaciones representan **cobertura del diseño**, no pruebas de una implementación ejecutada.

### A.2. Matriz completa de trazabilidad

| ID del criterio | Descripción resumida | Endpoint(s) relacionado(s) | Método(s) HTTP | ¿Cubierto en el diseño? |
|---|---|---|---|---|
| `RF-01-AC-1` | Registro válido | `/api/users` | `POST` | Directa (API) |
| `RF-01-AC-2` | Rechazo de datos de registro inválidos | `/api/users` | `POST` | Directa (API) |
| `RF-02-AC-1` | Inicio de sesión con credenciales válidas | `/api/sessions` | `POST` | Directa (API) |
| `RF-02-AC-2` | Rechazo de credenciales inválidas | `/api/sessions` | `POST` | Directa (API) |
| `RF-03-AC-1` | Creación de proyecto propio | `/api/projects` | `POST` | Directa (API) |
| `RF-03-AC-2` | Nuevo proyecto visible en el historial | `/api/projects` | `GET` | Directa (API) |
| `RF-04-AC-1` | Carga de audio MP3, WAV o AIFF válido | `/api/projects/{project_id}/audio` | `POST` | Directa (API) |
| `RF-04-AC-2` | Rechazo del audio que incumpla las restricciones | `/api/projects/{project_id}/audio` | `POST` | Directa (API) |
| `RF-05-AC-1` | Transcripción verificada, versión seleccionada y resultados coherentes | `/api/projects/{project_id}/processing-attempts`<br>`/api/projects/{project_id}/transcription` | `POST`<br>`GET` | Compartida (API + trabajador) |
| `RF-05-AC-2` | Altura, ritmo y duración de las notas | `/api/projects/{project_id}/transcription` | `GET` | Compartida (API + trabajador) |
| `RF-06-AC-1` | Consulta del estado pendiente, procesando, completado o error | `/api/projects/{project_id}`<br>`/api/projects/{project_id}/processing-attempts/{attempt_id}` | `GET`<br>`GET` | Directa (API) |
| `RF-06-AC-2` | Consulta del estado final y advertencias | `/api/projects/{project_id}`<br>`/api/projects/{project_id}/processing-attempts/{attempt_id}` | `GET`<br>`GET` | Directa (API) |
| `RF-07-AC-1` | Visualización de la partitura completada | `/api/projects/{project_id}/results/pdf` | `GET` | Compartida (API + frontend) |
| `RF-07-AC-2` | No presentar partitura provisional como definitiva | `/api/projects/{project_id}/results/pdf` | `GET` | Compartida (API + frontend) |
| `RF-08-AC-1` | Descarga de MIDI definitivo | `/api/projects/{project_id}/results/midi` | `GET` | Directa (API) |
| `RF-08-AC-2` | Descarga de PDF definitivo | `/api/projects/{project_id}/results/pdf` | `GET` | Directa (API) |
| `RF-09-AC-1` | Historial de proyectos del usuario | `/api/projects` | `GET` | Directa (API) |
| `RF-09-AC-2` | Nombre, fecha y estado en el historial | `/api/projects` | `GET` | Directa (API) |
| `RF-10-AC-1` | Recuperación de partitura sin reprocesar | `/api/projects/{project_id}/results/pdf` | `GET` | Directa (API) |
| `RF-10-AC-2` | Descargas repetidas de MIDI y PDF | `/api/projects/{project_id}/results/pdf`<br>`/api/projects/{project_id}/results/midi` | `GET`<br>`GET` | Directa (API) |
| `RF-11-AC-1` | Confirmación previa a eliminar | `/api/projects/{project_id}` | `DELETE` | Fuera de API (frontend); operación relacionada |
| `RF-11-AC-2` | Eliminación del proyecto y de sus datos | `/api/projects/{project_id}` | `DELETE` | Compartida (API + almacenamiento) |
| `RF-11-AC-3` | Cancelación y eliminación con procesamiento activo | `/api/projects/{project_id}` | `DELETE` | Compartida (API + trabajador) |
| `RF-12-AC-1` | Reintento después de un procesamiento fallido | `/api/projects/{project_id}/processing-attempts` | `POST` | Compartida (API + trabajador) |
| `RF-12-AC-2` | Reutilización del proyecto y audio original | `/api/projects/{project_id}/processing-attempts` | `POST` | Directa (API) |
| `RF-13-AC-1` | Verificación musical de la transcripción inicial | `/api/projects/{project_id}/processing-attempts`<br>`/api/projects/{project_id}/processing-attempts/{attempt_id}/verifications` | `POST`<br>`GET` | Compartida (API + trabajador) |
| `RF-13-AC-2` | Corrección automática seguida de reevaluación | `/api/projects/{project_id}/processing-attempts`<br>`/api/projects/{project_id}/processing-attempts/{attempt_id}/verifications` | `POST`<br>`GET` | Compartida (API + trabajador) |
| `RF-13-AC-3` | Máximo de dos correcciones y selección de la mejor versión | `/api/projects/{project_id}/processing-attempts`<br>`/api/projects/{project_id}/processing-attempts/{attempt_id}/verifications` | `POST`<br>`GET` | Compartida (API + trabajador) |
| `RF-13-AC-4` | Consulta del informe y advertencias de verificación | `/api/projects/{project_id}/processing-attempts/{attempt_id}/verifications` | `GET` | Directa (API) |

### A.3. Cobertura, excepciones y decisiones sobre brechas

**Resultado cuantitativo.** Los 29 criterios del SRS aparecen en la matriz. De ellos, 28 están mencionados en extensiones `x-acceptance-criteria` de una o varias operaciones OpenAPI; el criterio `RF-11-AC-1` se relaciona con `DELETE /api/projects/{project_id}`, pero su confirmación previa **no está implementada por el contrato HTTP**. Esta es una separación intencional de responsabilidades, no un endpoint omitido por accidente.

**RF-11-AC-1 — Confirmación previa a eliminar (brecha fuera del alcance de la API).** El frontend debe solicitar una confirmación explícita antes de emitir `DELETE /api/projects/{project_id}`. La API ejecuta la eliminación autorizada, pero no sustituye la interacción de confirmación. No se añade una operación artificial para confirmarla. La interfaz deberá validarse con una prueba específica; el endpoint correspondiente conserva la trazabilidad de `RF-11-AC-2` y `RF-11-AC-3`.

**RF-05-AC-1 y RF-05-AC-2 — Transcripción musical (cobertura compartida).** La API permite solicitar el procesamiento y recuperar la representación musical seleccionada, pero el reconocimiento de alturas, ritmo y duraciones, la verificación, la selección de la mejor versión y la exportación requieren la ejecución del trabajador musical. Asimismo, los endpoints de resultados PDF y MIDI exponen los archivos definitivos correspondientes a esa selección. Las pruebas futuras deberán demostrar que estos resultados coinciden.

**RF-07-AC-1 y RF-07-AC-2 — Visualización y disponibilidad (cobertura compartida).** El endpoint de PDF únicamente puede ofrecer una partitura definitiva cuando está disponible y utiliza una respuesta de conflicto cuando aún no lo está. El frontend debe mostrar el archivo recibido y evitar presentar una transcripción incompleta como finalizada.

**RF-11-AC-2 y RF-11-AC-3 — Eliminación y cancelación (cobertura compartida).** La operación DELETE define el resultado HTTP observable. La eliminación efectiva de audios, archivos definitivos, MIDI provisionales y registros internos exige coordinación entre backend, trabajador y almacenamiento privado; deben comprobarse los casos de ejecución activa y los fallos parciales.

**RF-12-AC-1 — Reintento (cobertura compartida).** La API acepta crear un nuevo intento para un proyecto fallido sin recargar el audio, pero la nueva ejecución musical corresponde al trabajador asíncrono.

**RF-13-AC-1, RF-13-AC-2 y RF-13-AC-3 — Verificación musical (cobertura compartida).** POST inicia un proceso que incluye la síntesis del MIDI provisional, la comparación musical con la grabación original y hasta dos correcciones adicionales. GET permite consultar evaluaciones, correcciones y selección. El cumplimiento se verificará con pruebas de la ejecución interna; el contrato no demuestra por sí solo precisión o mejoras musicales.

**RF-13-AC-4 — Información al usuario.** El endpoint del informe hace consultables el estado de evaluación, las correcciones y las advertencias. El resultado puede ser no concluyente aunque exista una transcripción utilizable; no se atribuye certeza absoluta a la verificación.

**Conclusión de cobertura.** No se detectaron criterios del SRS sin vía de atención en el diseño global. Existe una única responsabilidad de interfaz sin endpoint exclusivo (`RF-11-AC-1`) y varias coberturas compartidas con los módulos internos que se documentan expresamente. No se declara implementado ni probado ningún comportamiento por el mero hecho de estar descrito en OpenAPI.

## Sección B. Decisiones de diseño de la API

### B.1. Selección de recursos y endpoints

La API de Audio2Score fue diseñada bajo el enfoque *Specification-Driven Design* (SDD), tomando como referencia el SRS 2.0 y la arquitectura de backend monolítico modular con procesamiento musical asíncrono aprobada previamente.

Se identificaron ocho grupos de recursos: `users`, `sessions`, `projects`, `audio`, `processing-attempts`, `transcription`, `results` y `verifications`, organizados en 13 operaciones HTTP.

La selección responde a las responsabilidades funcionales del sistema:

- **Usuarios y sesiones:** permiten registrar cuentas y autenticar usuarios mediante JWT.
- **Proyectos:** proporcionan las operaciones necesarias para crear, consultar, listar y eliminar proyectos musicales.
- **Audio:** permite cargar y validar las grabaciones originales asociadas a cada proyecto.
- **Intentos de procesamiento:** permite iniciar transcripciones, reintentar operaciones fallidas y consultar sus estados.
- **Transcripción:** proporciona acceso a la representación musical estructurada seleccionada como resultado.
- **Resultados:** permite visualizar o descargar las partituras PDF y los archivos MIDI definitivos.
- **Verificaciones:** permite consultar las evaluaciones musicales, las correcciones efectuadas y las limitaciones detectadas.

Esta organización separa las responsabilidades de gestión de datos y consulta de resultados, sin trasladar al cliente la implementación interna de los algoritmos musicales.

El procesamiento se inicia mediante una operación HTTP, pero la transcripción, síntesis MIDI, comparación con el audio original y corrección automática son ejecutadas internamente por el trabajador musical.

**Funcionalidades excluidas**

Se mantuvieron fuera del contrato las funcionalidades que no pertenecen al alcance aprobado del MVP: edición manual de partituras, separación de múltiples instrumentos, colaboración entre usuarios, compartición pública de proyectos, autenticación multifactor y control de versiones accesible al usuario.

Tampoco se crearon endpoints independientes para ejecutar manualmente cada corrección musical. Las correcciones forman parte del flujo interno de procesamiento y no representan acciones que el usuario deba controlar directamente.

Esta decisión reduce la complejidad de implementación y mantiene la correspondencia con el SRS.

### B.2. Patrones de diseño incluidos y excluidos

**Paginación: incluida**

La operación `GET /api/projects` incorpora los parámetros opcionales `page` y `page_size`.

Se establecieron 20 proyectos por página como valor predeterminado y un máximo de 100.

La paginación permite consultar historiales de tamaño variable sin transferir necesariamente todos los proyectos en una sola solicitud. Se estableció también un ordenamiento descendente por fecha de creación, con desempate mediante el identificador del proyecto.

**Versionado en la ruta: excluido del MVP**

La especificación identifica el contrato como versión `1.0.0` mediante el atributo `info.version`.

Sin embargo, no incorpora un identificador de versión en las rutas, como `/api/v1/projects`.

Esta decisión evita introducir una estrategia de versionado de rutas antes de que existan distintas versiones públicas de la API. Si posteriormente se requieren modificaciones incompatibles del contrato, deberá definirse una política explícita de evolución y compatibilidad.

La versión documental de OpenAPI no debe confundirse con una estrategia de versionado de endpoints.

**Filtrado: excluido inicialmente**

El listado de proyectos no incorpora parámetros de filtrado por nombre, fecha o estado.

El SRS exige que los usuarios puedan consultar el historial de sus proyectos, pero no establece búsquedas o filtros específicos.

Por ello, se decidió implementar primero la consulta paginada y ordenada. Los filtros podrán incorporarse posteriormente si nuevos requerimientos justifican su necesidad.

**Idempotencia: incluida para solicitudes de procesamiento**

La operación `POST /api/projects/{project_id}/processing-attempts` admite opcionalmente la cabecera `Idempotency-Key`.

Este mecanismo permite identificar solicitudes repetidas y evitar la creación de trabajos duplicados como consecuencia de fallos de comunicación.

La implementación deberá conservar la relación entre clave y solicitud original, devolver el intento previamente aceptado cuando corresponda y rechazar mediante `409 Conflict` la reutilización de una clave para una solicitud diferente.

**Seguridad: autenticación y autorización**

El contrato establece Bearer Token (JWT) para las operaciones protegidas.

La autorización se verificará en el backend, asegurando que cada usuario solamente pueda acceder a sus proyectos, archivos y resultados.

La duración del token se estableció en 3,600 segundos. Los mecanismos de autenticación multifactor y de inicio de sesión mediante proveedores externos permanecen fuera del MVP.

### B.3. Revisión crítica de las propuestas del agente de IA

La generación inicial de la especificación fue sometida a revisión técnica para identificar problemas de conformidad con los principios REST y las reglas HTTP.

Se identificaron tres oportunidades de mejora.

**Primera observación: autenticación HTTP incompleta**

El contrato incluía respuestas `401 Unauthorized` para operaciones protegidas, pero no especificaba inicialmente la cabecera `WWW-Authenticate`.

La revisión permitió identificar esta omisión y corregirla mediante la incorporación del desafío Bearer.

**Segunda observación: riesgo de duplicación de procesamientos**

El diseño inicial utilizaba correctamente POST para crear intentos de procesamiento, pero no permitía identificar de forma explícita solicitudes repetidas después de un fallo de comunicación.

Se incorporó la cabecera `Idempotency-Key`, conservando POST como método de creación y estableciendo reglas para recuperar el intento original sin duplicarlo.

**Tercera observación: diferenciación de códigos de error**

La especificación inicial no distinguía suficientemente entre tipos de contenido HTTP incompatibles y archivos musicales que incumplían restricciones de validación.

Se precisó la utilización de `413` para archivos demasiado grandes, `415` para tipos de contenido HTTP no admitidos y `422` para archivos cuyo contenido no cumple las condiciones del sistema.

Estas observaciones y las correspondientes modificaciones quedaron documentadas en `revision_rest.md` y reflejadas en `openapi.yaml`.

### B.4. Limitaciones del agente y validación humana

La revisión también evidenció que la generación de una especificación mediante inteligencia artificial no garantiza automáticamente su compatibilidad con todas las herramientas de validación.

Durante la comprobación en Swagger Editor fue necesario corregir una definición de cabeceras HTTP y una enumeración que incluía un valor nulo incompatible con el tipo declarado.

Posteriormente, durante una edición, se detectó una clave YAML duplicada, que fue eliminada antes de concluir la validación.

Estos problemas demostraron la necesidad de revisar tanto la validez del formato como la consistencia semántica de los esquemas.

Adicionalmente, se identificó que ciertos criterios de aceptación no pueden satisfacerse exclusivamente mediante operaciones HTTP.

Por ejemplo, RF-11-AC-1 exige confirmar la eliminación de un proyecto antes de ejecutarla. La confirmación corresponde al frontend, mientras que la operación DELETE ejecuta la eliminación autorizada.

Asimismo, los criterios relacionados con la síntesis MIDI, la verificación musical y la corrección automática dependen de procesos internos que el contrato describe, pero no implementa.

Por tanto, el diseño establece responsabilidades y comportamientos esperados, sin presentar la existencia de un endpoint como evidencia suficiente de que su funcionalidad ya fue implementada y probada.

### B.5. Conclusión de las decisiones de diseño

Las decisiones adoptadas buscan equilibrar el cumplimiento de los requerimientos funcionales, la coherencia arquitectónica, la seguridad y la simplicidad de implementación.

La API utiliza recursos identificables, métodos HTTP acordes con sus responsabilidades, respuestas documentadas, esquemas reutilizables y mecanismos explícitos de trazabilidad.

La paginación y la prevención de solicitudes duplicadas se incorporaron por su utilidad concreta, mientras que el filtrado y el versionado de rutas se reservaron para futuras necesidades.

La revisión crítica de las propuestas del agente permitió mejorar el contrato y documentar sus limitaciones.

El resultado constituye una especificación preparada para orientar la implementación y las pruebas posteriores de Audio2Score, sin asumir que dichas actividades ya se han completado.
