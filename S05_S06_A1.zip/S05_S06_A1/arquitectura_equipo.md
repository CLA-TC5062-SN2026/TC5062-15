# Arquitectura de Audio2Score

Se adopta una arquitectura cliente-servidor con una SPA y un monolito modular por capas. El procesamiento de audio se ejecuta de forma asíncrona en un worker separado del ciclo de petición HTTP. La cola durable, el publicador y el outbox permiten mantener el estado y recuperar intentos; el motor de transcripción se ejecuta localmente dentro del worker.

```mermaid
flowchart LR
    U[Usuario] -->|Navegador| SPA[SPA web]

    subgraph Sistema["Audio2Score - despliegue de la aplicación"]
        SPA -->|HTTPS / API REST| API[API REST<br/>Monolito modular]

        subgraph API_Modules["Módulos de negocio"]
            AUTH[Identidad y acceso]
            PROJECTS[Proyectos y archivos]
            PROCESSING[Procesamiento y transcripciones]
            EXPORT[Exportación MIDI y PDF]
        end

        API --> AUTH
        API --> PROJECTS
        API --> PROCESSING
        API --> EXPORT

        API -->|lecturas y transacciones| DB[(Base de datos relacional)]
        AUTH -->|usuarios, hashes y revocaciones| DB
        AUTH -->|verifica JWT y propietario| PROJECTS
        PROCESSING -->|guardar intento + outbox| DB
        DB -->|eventos pendientes| PUBLISHER[Publicador de outbox]
        PUBLISHER -->|publicar trabajo| QUEUE[(Cola durable)]
        QUEUE -->|consumo asíncrono| WORKER[Worker de procesamiento]
        WORKER -->|MotorTranscripcion local| ENGINE[Motor musical]
        WORKER -->|guardar estado, notas y versiones| DB
        PROJECTS -->|audio de origen| STORAGE[(Almacenamiento de archivos)]
        WORKER -->|leer audio / guardar artefactos| STORAGE
        EXPORT -->|leer transcripción y crear MIDI/PDF| STORAGE
    end
```

## Responsabilidades y límites

- **SPA:** presenta proyectos, estados y partituras; permite revisar/corregir y solicitar exportaciones. No accede directamente a la base de datos.
- **API REST:** el middleware valida JWT firmados, comprueba expiración y revocación, y autentica al usuario antes de ejecutar rutas protegidas.
- **Identidad y acceso:** almacena contraseñas con bcrypt, emite JWT con expiración configurada por entorno e invalida tokens al cerrar sesión.
- **Autorización:** cada consulta y operación de proyecto se limita al propietario asociado al usuario autenticado. El modelo actual no define roles adicionales.
- **Módulos de negocio:** separan autenticación, proyectos/audio, procesamiento/transcripciones y exportación dentro de un único backend.
- **Base de datos relacional:** conserva usuarios, hashes de contraseña, proyectos, metadatos de audio, intentos, versiones, notas y tokens revocados.
- **Publicador y cola durable:** entregan solicitudes de procesamiento al worker sin bloquear la petición web.
- **Worker y motor local:** procesan audio, persisten estado y resultado, y permiten reintentos recuperables. El motor no se asume como servicio externo.
- **Almacenamiento de archivos:** mantiene audio de origen y artefactos generados; su política de acceso y borrado debe respetar la propiedad del proyecto y RNF-05.

La tecnología concreta de base de datos, broker y almacenamiento queda abierta para implementación; las propuestas individuales no justifican fijar un proveedor.
