# Diferencias y decisiones del diseño de equipo

## Aportes por integrante

| Integrante | OpenAPI | Diagrama de clases | Arquitectura |
|---|---|---|---|
| **Adrian (1)** | Propuso el contrato más amplio alineado al SRS actual: autenticación, proyectos, archivado/eliminación, carga y validación, inicio explícito de procesamiento, consultas y reintentos, transcripciones, revisiones, comparación, resumen y descargas MIDI/PDF. Trazó las operaciones a RF-01 a RF-16. | Incluyó Usuario, Proyecto, AudioFile, ProcessingJob, Transcription, MusicalNote y exportaciones MIDI/PDF. Añadió estados, intentos, notas estimadas y datos para descargas. | Propuso monolito modular en capas y procesamiento asíncrono mediante cola/worker, motivado por los trabajos largos y el equipo de un desarrollador. |
| **Ivan (2)** | Aportó nombres más orientados a recursos y sesiones, paginación, clave de idempotencia, configuración e historial de intentos, transcripciones versionadas y exportaciones de proyecto. Propuso iniciar automáticamente tras la carga. | Aportó la separación entre Transcripcion e historial VersionTranscripcion, origen de versión, resumen, notas con altura MIDI y los conceptos de outbox, idempotencia, leases y heartbeat. | Definió SPA cliente-servidor, monolito modular por capas, cola durable, outbox y worker; especificó que el motor corre localmente y planteó controles de recuperación. |
| **Daniel (3)** | Añadió explícitamente verificaciones/evaluaciones y reporte de correcciones, además de auth, proyectos, cargas, intentos, resultados y transcripción. Algunos IDs y nombres de requisitos corresponden a una versión distinta del SRS. | Aportó evaluaciones musicales, ciclos de corrección, pulsos musicales y límites de cardinalidad. Incluyó formatos y límites de archivo que se compararon con el SRS vigente. | Su ADR está alineado con la decisión cliente-servidor/worker de Ivan e incluye límites de confianza y privacidad; no agrega un estilo arquitectónico distinto. |

## Análisis de diferencias OpenAPI

### Consenso funcional

Los tres diseños incluyen registro/autenticación, gestión de proyectos, carga de audio, procesamiento asíncrono, consulta de transcripciones y disponibilidad de resultados MIDI/PDF. El alcance y la forma del contrato, sin embargo, no son idénticos.

### Gaps y propuestas parciales

- El contrato de Adrian es el que representa de forma más completa los requisitos vigentes: renombrar, archivar y eliminar proyectos; consulta de historial, estado y motivo de fallo; corrección, comparación, resumen y descargas de la versión vigente.
- Ivan aporta paginación, idempotencia, configuración de procesamiento e historial de versiones/intentos. Algunas extensiones son decisiones de implementación, no requisitos explícitos del SRS.
- Daniel propone endpoints de verificaciones y reportes de evaluación/corrección. No se incorporaron porque el SRS vigente no contiene esos requisitos.
- La operación de perfil (`/auth/me`) es complementaria a autenticación y no tiene un criterio de aceptación propio, por lo que se conserva ligada a RF-01-AC-2.

### Conflictos y resolución

| Conflicto | Resolución |
|---|---|
| Registro/inicio/cierre con `/auth/*`, `/users` + `/sessions`, o `/api/users` + `/api/sessions`. | Se normalizó a `/auth/register`, `/auth/login`, `/auth/logout` y `/auth/me`, con bearer JWT y modelos de request/response explícitos. |
| Inicio explícito después de cargar frente a inicio automático al cargar. | Se eligió inicio **explícito**: RF-05 describe una solicitud del usuario y su criterio de aceptación requiere iniciarlo. La carga valida el audio, pero no crea el trabajo. |
| `POST` de carga individual frente a `PUT` del audio actual del proyecto. | Se eligió `POST /projects/{projectId}/audio-files` con `multipart/form-data`: cada carga aceptada crea un recurso de audio identificable y el patrón de Adrian ya cubre la carga según RF-03/RF-04. |
| Identificadores de job, attempt y sesión; rutas de estado/reintento. | Se normalizó a `ProcessingAttempt` bajo el proyecto, con consulta individual y `POST .../{attemptId}/retry`; esto deja visibles estado, número y motivo del intento. |
| Actualizar transcripción por `PUT` sobrescribiendo frente a crear versiones/revisiones. | Se conservan versiones inmutables y una referencia a la vigente. Una corrección crea una versión nueva, satisfaciendo RF-09 y RF-13-AC-2 sin destruir historial. |
| Descargas ligadas a una transcripción identificada frente a rutas del proyecto. | Se seleccionaron rutas del proyecto para exportar la **versión vigente**, como exigen RF-11-AC-1 y RF-12-AC-1. El API devuelve el binario y protege la propiedad del proyecto. |
| Códigos de respuesta variados (`200`, `201`, `202`, `204`) y distintos formatos de errores. | Se normalizaron errores en `Error`/`ValidationError`. Creación de recursos usa `201`, trabajo asíncrono aceptado `202`, eliminación/cierre sin cuerpo `204`, descargas `200`. Se mantiene `409` para correo repetido o estado incompatible. |
| IDs de aceptación discordantes en las propuestas 2 y 3. | Se usaron únicamente identificadores presentes en `SRS_equipo.md`; no se trasladaron IDs por similitud de nombre. |

## Análisis de diferencias del diagrama de clases

### Consenso

Los tres modelos reconocen Usuario, Proyecto, un archivo de audio asociado, procesamiento, transcripción con notas y resultados/exportaciones. También representan la relación de propiedad Usuario–Proyecto y el estado de procesamiento.

### Gaps

- Adrian detalló formatos, tamaño/duración, confianza, estimación y exportaciones MIDI/PDF.
- Ivan añadió versiones explícitas, resumen de transcripción y metadatos de operación del worker (lease, heartbeat, motor y configuración).
- Daniel añadió evaluación musical, correcciones, pulsos, y cardinalidades específicas de ciclos/resultados.
- Evaluación, pulsos, ciclos limitados y heartbeat/lease no se incluyeron como clases del modelo API consolidado: no son contratos funcionales definidos en el SRS vigente. Outbox/cola y almacenamiento se conservan en arquitectura como infraestructura, no como entidades del dominio expuestas por el API.

### Conflictos y resolución

- **Idiomas y nombres:** se usaron nombres canónicos en inglés alineados con los schemas del OpenAPI (`User`, `Project`, `AudioFile`, `ProcessingAttempt`, `Transcription`, `MusicalNote`).
- **Transcripción como un único resultado o historial separado:** se consolidó como registros/versiones de `Transcription`, con `version`, `origin`, `basedOnTranscriptionId` y `Project.currentTranscriptionId`. La corrección crea una versión nueva; el historial no se sobrescribe.
- **Datos de usuario:** el modelo API conserva id, email y fecha de creación. Contraseñas y hashes quedan fuera del modelo de clases API y nunca se exponen en la respuesta `User`.
- **Audio:** se limitó la enumeración a MP3/WAV según RF-03 y RNF-06. La propuesta de AIFF no corresponde al mínimo acordado en el SRS y no se incorporó.
- **Notas:** se preservaron altura, inicio, duración, confianza, estimación y baja confianza para cubrir RF-07 y RF-10.
- **Exportaciones y evaluaciones:** MIDI/PDF se mantienen como respuestas binarias del API, no como entidades persistentes obligatorias. Evaluación musical y registro detallado de correcciones quedan fuera del modelo porque el SRS actual no los solicita.
- **Trazabilidad de atributos:** el diagrama refleja los campos de los schemas de request y response del OpenAPI consolidado; campos internos como `passwordHash` se marcan como no expuestos.

## Análisis de diferencias de arquitectura

Los tres ADR favorecen un monolito modular con procesamiento separado y asíncrono. Ivan y Daniel explicitan el cliente SPA, el motor local y la protección de privacidad; Adrian enfatiza la viabilidad operativa del monolito modular y la cola. La arquitectura consolidada combina estas decisiones: SPA + API REST modular, base relacional, almacenamiento de archivos, outbox/publicador, cola durable y worker que invoca un motor local. No se fija un proveedor específico ni se adoptan microservicios, ya que no se justifican por el alcance y el tamaño del equipo. La carga y el procesamiento quedan separados en concordancia con el flujo explícito del SRS.

## Artefactos consolidados

- `openapi_equipo.yaml`: contrato REST y criterios de aceptación por operación.
- `diagrama_clases_equipo.puml`: modelo de dominio/DTOs consistente con los schemas.
- `arquitectura_equipo.md`: diagrama y responsabilidades de los componentes.
