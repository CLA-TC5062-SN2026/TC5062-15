-- Audio2Score - MySQL 8.0.16+
-- CHECK constraints are enforced starting with MySQL 8.0.16.
CREATE DATABASE IF NOT EXISTS audio2score
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE audio2score;

CREATE TABLE user_account (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_user_account_email (email),
  CONSTRAINT chk_user_account_email CHECK (CHAR_LENGTH(TRIM(email)) > 0)
) ENGINE=InnoDB;

CREATE TABLE project (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  owner_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  name VARCHAR(120) NOT NULL,
  status ENUM('pendiente', 'procesando', 'completado', 'fallido')
    NOT NULL DEFAULT 'pendiente',
  audio_file_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  current_transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  failure_reason TEXT NULL,
  archived_at DATETIME(3) NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
    ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY ix_project_owner_archive_created (owner_id, archived_at, created_at),
  KEY ix_project_owner_name (owner_id, name),
  CONSTRAINT chk_project_name CHECK (CHAR_LENGTH(TRIM(name)) > 0),
  CONSTRAINT fk_project_owner
    FOREIGN KEY (owner_id) REFERENCES user_account (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE audio_file (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  project_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  format ENUM('MP3', 'WAV') NOT NULL,
  size_bytes BIGINT NOT NULL,
  duration_seconds DECIMAL(10, 3) NULL,
  status ENUM('aceptado', 'rechazado') NOT NULL,
  rejection_reason TEXT NULL,
  uploaded_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_audio_file_project (project_id),
  UNIQUE KEY uq_audio_file_project_id (project_id, id),
  CONSTRAINT chk_audio_file_size
    CHECK (size_bytes > 0 AND size_bytes <= 100000000),
  CONSTRAINT chk_audio_file_duration
    CHECK (duration_seconds IS NULL OR (duration_seconds > 0 AND duration_seconds <= 900)),
  CONSTRAINT chk_audio_file_rejection
    CHECK (status = 'aceptado' OR rejection_reason IS NOT NULL),
  CONSTRAINT fk_audio_file_project
    FOREIGN KEY (project_id) REFERENCES project (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE processing_attempt (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  project_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  status ENUM('pendiente', 'procesando', 'completado', 'fallido')
    NOT NULL DEFAULT 'pendiente',
  attempt_number INT UNSIGNED NOT NULL,
  configuration JSON NULL,
  error_message TEXT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  started_at DATETIME(3) NULL,
  finished_at DATETIME(3) NULL,
  transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_processing_attempt_project_number (project_id, attempt_number),
  UNIQUE KEY uq_processing_attempt_project_id (project_id, id),
  UNIQUE KEY uq_processing_attempt_transcription (project_id, transcription_id),
  KEY ix_processing_attempt_project_created (project_id, created_at),
  CONSTRAINT chk_processing_attempt_number CHECK (attempt_number > 0),
  CONSTRAINT chk_processing_attempt_times
    CHECK (finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at),
  CONSTRAINT fk_processing_attempt_project
    FOREIGN KEY (project_id) REFERENCES project (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE transcription (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  project_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  processing_attempt_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  based_on_transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  version INT UNSIGNED NOT NULL,
  origin ENUM('automatica', 'correccion_usuario') NOT NULL DEFAULT 'automatica',
  tempo_estimated DECIMAL(8, 3) NULL,
  key_estimated VARCHAR(32) NULL,
  time_signature_estimated VARCHAR(16) NULL,
  is_draft BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_transcription_project_version (project_id, version),
  UNIQUE KEY uq_transcription_project_id (project_id, id),
  UNIQUE KEY uq_transcription_processing_attempt (project_id, processing_attempt_id),
  KEY ix_transcription_project_created (project_id, created_at),
  CONSTRAINT chk_transcription_version CHECK (version > 0),
  CONSTRAINT chk_transcription_tempo
    CHECK (tempo_estimated IS NULL OR tempo_estimated > 0),
  CONSTRAINT fk_transcription_project
    FOREIGN KEY (project_id) REFERENCES project (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_transcription_processing_attempt
    FOREIGN KEY (project_id, processing_attempt_id)
    REFERENCES processing_attempt (project_id, id)
    ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_transcription_based_on
    FOREIGN KEY (project_id, based_on_transcription_id)
    REFERENCES transcription (project_id, id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE musical_note (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  position INT UNSIGNED NOT NULL,
  pitch VARCHAR(32) NOT NULL,
  start_time_seconds DECIMAL(12, 6) NOT NULL,
  duration_seconds DECIMAL(12, 6) NOT NULL,
  confidence DECIMAL(5, 4) NULL,
  is_estimated BOOLEAN NOT NULL,
  is_low_confidence BOOLEAN NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_musical_note_transcription_position (transcription_id, position),
  UNIQUE KEY uq_musical_note_transcription_id (transcription_id, id),
  CONSTRAINT chk_musical_note_start CHECK (start_time_seconds >= 0),
  CONSTRAINT chk_musical_note_duration CHECK (duration_seconds > 0),
  CONSTRAINT chk_musical_note_confidence
    CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
  CONSTRAINT fk_musical_note_transcription
    FOREIGN KEY (transcription_id) REFERENCES transcription (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE transcription_summary (
  transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  notes_count INT UNSIGNED NOT NULL,
  coverage_estimated_percent DECIMAL(5, 2) NULL,
  tempo_estimated DECIMAL(8, 3) NULL,
  key_estimated VARCHAR(32) NULL,
  estimated_fields JSON NOT NULL,
  PRIMARY KEY (transcription_id),
  CONSTRAINT chk_transcription_summary_coverage
    CHECK (coverage_estimated_percent IS NULL OR
      (coverage_estimated_percent >= 0 AND coverage_estimated_percent <= 100)),
  CONSTRAINT chk_transcription_summary_tempo
    CHECK (tempo_estimated IS NULL OR tempo_estimated > 0),
  CONSTRAINT chk_transcription_summary_fields
    CHECK (JSON_TYPE(estimated_fields) = 'ARRAY'),
  CONSTRAINT fk_transcription_summary_transcription
    FOREIGN KEY (transcription_id) REFERENCES transcription (id)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE low_confidence_segment (
  transcription_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  note_index INT UNSIGNED NOT NULL,
  reason VARCHAR(500) NOT NULL,
  PRIMARY KEY (transcription_id, note_index),
  CONSTRAINT chk_low_confidence_reason CHECK (CHAR_LENGTH(TRIM(reason)) > 0),
  CONSTRAINT fk_low_confidence_segment_note
    FOREIGN KEY (transcription_id, note_index)
    REFERENCES musical_note (transcription_id, position)
    ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;

-- Composite foreign keys enforce that the selected resources belong to the
-- same project as the owning row.
ALTER TABLE project
  ADD CONSTRAINT fk_project_current_audio
    FOREIGN KEY (id, audio_file_id)
    REFERENCES audio_file (project_id, id)
    ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT fk_project_current_transcription
    FOREIGN KEY (id, current_transcription_id)
    REFERENCES transcription (project_id, id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE processing_attempt
  ADD CONSTRAINT fk_processing_attempt_transcription
    FOREIGN KEY (project_id, transcription_id)
    REFERENCES transcription (project_id, id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

CREATE TABLE revoked_token (
  token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  expires_at DATETIME(3) NOT NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (token_id),
  KEY ix_revoked_token_expires_at (expires_at)
) ENGINE=InnoDB;
