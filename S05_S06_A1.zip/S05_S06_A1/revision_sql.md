# Revisión del esquema MySQL


### ¿Están representadas todas las entidades del diagrama de clases?

Sí. El esquema crea tablas para las entidades persistentes `User`, `Project`, `AudioFile`, `ProcessingAttempt`, `Transcription`, `MusicalNote` y `TranscriptionSummary`. También incluye `LowConfidenceSegment` para guardar el motivo asociado a una nota de baja confianza y `revoked_token` para invalidar JWT al cerrar sesión.

Los DTOs `RegisterRequest`, `LoginRequest`, `ProjectCreateRequest`, `ProjectUpdateRequest`, `ProcessingRequest`, `TranscriptionRevisionRequest`, `AuthToken`, `ProjectDetail` y `ComparisonResponse` no tienen tablas, porque son solicitudes o respuestas y no entidades con persistencia propia. El archivo binario `AudioFileUploadRequest.file`, `audioFileUrl` y las exportaciones MIDI/PDF se gestionan fuera de MySQL; la base guarda metadatos cuando corresponde.

### ¿Están incluidos todos los atributos que deben persistirse?

Sí. Se persisten los atributos de las entidades y los campos adicionales necesarios para representar relaciones y conservar datos.


### ¿Las llaves foráneas reflejan correctamente las relaciones y cardinalidades?

Sí, las claves foráneas compuestas verifican que las referencias al audio, a la transcripción vigente y a las versiones relacionadas correspondan al mismo proyecto.

### ¿Los tipos de datos son coherentes con los schemas de OpenAPI?

Sí. Los UUID usan `CHAR(36)` con collation binaria, los valores `date-time` usan `DATETIME(3)`, los tamaños de archivo usan `BIGINT`, y los valores decimales utilizan `DECIMAL` para conservar precisión. Los estados y formatos se restringen mediante `ENUM`, `estimated_fields` y la configuración del intento se almacenan como `JSON`.

### ¿Se incluyeron las restricciones e índices que requiere el dominio?

Sí. Se incluyeron unicidad para el correo, un audio por proyecto, el número de intento y versión por proyecto, la posición de nota y las relaciones uno-a-uno. 

También se añadieron restricciones para nombres y correos no vacíos; audios de hasta 100 MB y 15 minutos; confianza entre 0 y 1; cobertura entre 0 y 100; números positivos.

### ¿Hay reglas del negocio que no puedan garantizarse solo con estas restricciones?

Sí. El esquema no puede exigir mediante una restricción simple que una transcripción tenga al menos una nota ni mantener sincronizados `Project.status`, el estado del último intento y sus marcas de tiempo. Estas reglas deben validarse en la aplicación, dentro de transacciones.

### ¿Qué otros archivos deben revisarse si se modifica el esquema?

Además de `esquema_bd.sql`, deben revisarse `diagrama_clases_equipo.puml`, `openapi_equipo.yaml` cuando cambien campos públicos, `diagrama_er.puml` y este documento. Si cambian reglas funcionales, también debe actualizarse el SRS. En la implementación, deben revisarse las migraciones, fixtures y pruebas de persistencia y contrato. Para bases ya creadas, `backend/migrations/001_processing_attempt_configuration.sql` incorpora la configuración opcional de intentos y `backend/migrations/002_revoked_token.sql` agrega revocación de JWT.

### ¿Cómo se importa y verifica el esquema?

El script requiere MySQL 8.0.16 o posterior. Debe ejecutarse en una instancia de MySQL, por ejemplo desde MySQL Workbench con **Run SQL Script** o desde la consola:

```text
mysql -u usuario -p < esquema_bd.sql
```

Después, verificar con:

```sql
USE audio2score;
SHOW TABLES;
```

**SQLiteOnline con el motor predeterminado SQLite no puede ejecutar este archivo MySQL.** El error `near "DATABASE": syntax error` ocurre porque SQLite no soporta `CREATE DATABASE` ni `USE`, y el resto del esquema también utiliza sintaxis y tipos específicos de MySQL. No es evidencia de un error de sintaxis en el dialecto MySQL. Si SQLiteOnline permite seleccionar un motor MySQL, hay que elegirlo explícitamente; de lo contrario, importa el archivo en una instancia de MySQL.

No se pudo ejecutar la importación en este entorno: no hay cliente/servidor MySQL, MariaDB ni Docker disponibles. La revisión realizada es estática y no demuestra que un servidor haya creado las tablas; el equipo debe ejecutar la importación y `SHOW TABLES` en MySQL 8.0.16+.

## Correcciones

- Se añadió `passwordHash` al modelo de clases como atributo interno requerido para la persistencia, sin exponerlo en OpenAPI.
- Se añadió `position` a `MusicalNote` para conservar el orden de las notas y relacionar `noteIndex` con la nota correspondiente.
- Se ajustó `coverageEstimatedPercent` en el diagrama de clases al rango `0..100`.
- Se aclaró en OpenAPI que el hash de credenciales y la posición de almacenamiento no son campos públicos del API.
- Se generó `diagrama_er.puml` para visualizar tablas, atributos y cardinalidades.
- Para soportar las opciones de procesamiento del endpoint, se añadió `configuration JSON` a `processing_attempt`, a los diagramas y al response schema `ProcessingAttempt`; `../backend/migrations/001_processing_attempt_configuration.sql` actualiza bases ya creadas.
- En A1 se desactivó el requisito OpenAPI de bearer global; en esta actividad A2 se habilitó JWT para las rutas protegidas y se documentaron las respuestas 401.

## Correcciones al código generado

- Se verificaron las 24 operaciones de `openapi_equipo.yaml` contra el mapa de rutas Flask. Se conservaron las rutas y métodos coincidentes, y se agregó la operación documentada de descarga del audio original para que la URL de comparación tenga un endpoint correspondiente.
- Se alinearon los códigos de respuesta documentados por operación con los códigos que puede producir la implementación: éxitos `200`, `201`, `202` o `204`; errores de entrada `400`, recurso inexistente `404`, conflictos `409`, validación `422` e internos `500`, según aplique.
- En A1 se quitaron `401` y `403` de las operaciones de recursos porque esa entrega excluía la seguridad; A2 las vuelve a proteger con JWT.
- Se eliminó un `409` que había quedado asignado por error a `POST /auth/logout` y se documentó `409` para `GET /projects` cuando no hay usuario registrado que asignar como propietario por defecto.
- Se añadieron respuestas compartidas `400`, `404`, `409`, `422` y `500` donde el código puede producirlas. Se agregó una prueba que compara ruta, método y conjunto exacto de códigos de cada operación con la especificación.
