# Revisión de seguridad

**¿El JWT tiene tiempo de expiración explícito (no "sin expiración")?**  
Sí. Cada token incluye el claim `exp`; su duración en segundos se configura con `JWT_EXPIRATION` y el ejemplo usa 3600 segundos.

**¿El endpoint `/register` devuelve la contraseña en la respuesta?**  
No. Solo devuelve `id`, `email` y `createdAt`. La contraseña se guarda como hash bcrypt.

**¿El middleware rechaza tokens con firma inválida o expirados?**  
Sí. Solo acepta JWT firmados con HS256, exige los claims necesarios y rechaza firma inválida, expiración, token ausente o token revocado.

**¿El secret del JWT está en código duro o en variable de entorno?**  
Está en la variable de entorno `JWT_SECRET`; no hay un secreto alternativo en código. Si falta o tiene menos de 32 bytes UTF-8, las solicitudes protegidas fallan explícitamente.

## Correcciones

Se corrigieron las brechas que tenía la implementación heredada de A1: se reemplazaron las sesiones en memoria por JWT, se añadió hash bcrypt, expiración configurable, middleware de autenticación y autorización por propietario. También se añadió revocación persistente para logout y se agregaron pruebas para tokens inválidos/expirados, hashes, logout y acceso cruzado a proyectos.

El modelo no define roles distintos; por eso, el control de autorización de esta entrega limita cada proyecto a su propietario autenticado.

## Protección de rutas

El OpenAPI aplica `bearerAuth` globalmente. Solo `POST /api/auth/register` y `POST /api/auth/login` declaran `security: []` y quedan públicas. El middleware de `backend/app.py` protege las demás operaciones `/api/...`; sus alias `/api/v1/auth/...` también se protegen, salvo los alias públicos de registro e inicio de sesión. `/health` no es una ruta `/api` y permanece libre para comprobar la disponibilidad del servicio.

Rutas protegidas, todas para **usuario autenticado**:

- `POST /api/auth/logout` y `GET /api/auth/me`.
- Proyectos: `GET, POST /api/v1/projects`; `GET, PATCH, DELETE /api/v1/projects/{projectId}`; `POST /api/v1/projects/{projectId}/archive`.
- Audio: `POST /api/v1/projects/{projectId}/audio-files`; `GET /api/v1/projects/{projectId}/audio-files/current`; `GET /api/v1/projects/{projectId}/audio-files/current/content`.
- Procesamiento: `GET, POST /api/v1/projects/{projectId}/processing-attempts`; `GET /api/v1/projects/{projectId}/processing-attempts/{attemptId}`; `POST /api/v1/projects/{projectId}/processing-attempts/{attemptId}/retry`.
- Transcripciones: `GET /api/v1/projects/{projectId}/transcriptions/current`; `GET /api/v1/projects/{projectId}/transcriptions`; `POST /api/v1/projects/{projectId}/transcriptions/current/revisions`; `GET /api/v1/projects/{projectId}/transcriptions/current/comparison`; `GET /api/v1/projects/{projectId}/transcriptions/current/summary`.
- Exportaciones: `GET /api/v1/projects/{projectId}/transcriptions/current/exports/midi` y `/pdf`.

Además de validar la identidad, las operaciones de proyectos, audio, procesamiento, transcripciones y exportación exigen que el usuario sea propietario del proyecto. Un recurso ajeno se responde como `404`. No hay roles como profesor/estudiante ni administrador/usuario en el esquema ni en el contrato, así que no aplica una prueba de rol incorrecto ni se genera un `403` por roles.

### Verificación desde terminal

Se probó la API local contra MySQL `audio2score` con un usuario y un proyecto temporales, eliminados al terminar:

| Caso | Solicitud | Resultado |
|---|---|---|
| Ruta protegida sin token | `GET /api/v1/projects` | `401 UNAUTHORIZED` |
| JWT modificado en un carácter | `GET /api/v1/projects` | `401 UNAUTHORIZED` |
| Ruta protegida con JWT válido | `GET /api/v1/projects` | `200`, cuerpo JSON (lista de proyectos) |
| CRUD como dueño autenticado | `POST /api/v1/projects`, luego `GET /api/v1/projects/{projectId}` | `201`; después `200` y el nombre persistido coincide |
| Limpieza de los datos de prueba | `DELETE /api/v1/projects/{projectId}` | `204` |
| Token con rol incorrecto | No aplica | No existen roles definidos; la política aplicable es propiedad del proyecto |