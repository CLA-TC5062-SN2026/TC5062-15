import styles from './Button.module.css'

export default function Button({
  variant = 'primary',
  loading = false,
  disabled = false,
  fullWidth = false,
  type = 'button',
  className = '',
  onClick,
  children,
  ...rest
}) {
  // aria-disabled (no disabled) mantiene el foco del teclado mientras carga
  const handleClick = (event) => {
    if (loading) {
      event.preventDefault()
      return
    }
    onClick?.(event)
  }

  const classes = [
    styles.button,
    styles[variant],
    fullWidth && styles.fullWidth,
    className,
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <button
      type={type}
      className={classes}
      disabled={disabled}
      aria-disabled={loading || undefined}
      aria-busy={loading}
      onClick={handleClick}
      {...rest}
    >
      {loading && <span className={styles.spinner} aria-hidden="true" />}
      {/* opacity (no visibility) conserva el nombre accesible y el ancho mientras carga */}
      <span className={loading ? styles.hiddenLabel : undefined}>{children}</span>
    </button>
  )
}
