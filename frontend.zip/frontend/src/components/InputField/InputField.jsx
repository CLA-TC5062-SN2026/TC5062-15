import { useId } from 'react'
import styles from './InputField.module.css'

export default function InputField({
  label,
  id,
  type = 'text',
  error,
  hint,
  required = false,
  className = '',
  ...rest
}) {
  const generatedId = useId()
  const inputId = id ?? generatedId
  const messageId = `${inputId}-message`
  const message = error || hint

  return (
    <div className={[styles.field, className].filter(Boolean).join(' ')}>
      <label htmlFor={inputId} className={styles.label}>
        {label}
        {required && <span aria-hidden="true"> *</span>}
      </label>
      <input
        id={inputId}
        type={type}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={message ? messageId : undefined}
        className={[styles.input, error && styles.inputError].filter(Boolean).join(' ')}
        {...rest}
      />
      {message && (
        <p id={messageId} className={error ? styles.error : styles.hint} role={error ? 'alert' : undefined}>
          {message}
        </p>
      )}
    </div>
  )
}
