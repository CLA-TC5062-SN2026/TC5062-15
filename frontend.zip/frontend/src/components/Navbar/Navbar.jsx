import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'
import Button from '../Button'
import styles from './Navbar.module.css'

// Si no se pasan isAuthenticated/user/onLogout, se toman de AuthContext.
export default function Navbar({ brand = 'Audio2Score', links = [], isAuthenticated, user, onLogout }) {
  const auth = useAuth()
  const authenticated = isAuthenticated ?? auth.isAuthenticated
  const currentUser = user ?? auth.user
  const handleLogout = onLogout ?? auth.logout
  const [open, setOpen] = useState(false)

  const closeMenu = () => setOpen(false)

  return (
    <header className={styles.navbar}>
      <Link to="/" className={styles.brand} onClick={closeMenu}>
        {brand}
      </Link>

      <button
        type="button"
        className={styles.toggle}
        aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
        aria-expanded={open}
        aria-controls="main-menu"
        onClick={() => setOpen((value) => !value)}
      >
        <span className={styles.bar} />
        <span className={styles.bar} />
        <span className={styles.bar} />
      </button>

      <nav id="main-menu" aria-label="Principal" className={[styles.menu, open && styles.menuOpen].filter(Boolean).join(' ')}>
        {authenticated ? (
          <>
            {links.map(({ to, label }) => (
              <NavLink key={to} to={to} className={styles.link} onClick={closeMenu}>
                {label}
              </NavLink>
            ))}
            {currentUser?.email && <span className={styles.user}>{currentUser.email}</span>}
            <Button variant="secondary" onClick={handleLogout}>
              Cerrar sesión
            </Button>
          </>
        ) : (
          <>
            <NavLink to="/login" className={styles.link} onClick={closeMenu}>
              Iniciar sesión
            </NavLink>
            <NavLink to="/register" className={styles.link} onClick={closeMenu}>
              Registrarse
            </NavLink>
          </>
        )}
      </nav>
    </header>
  )
}
