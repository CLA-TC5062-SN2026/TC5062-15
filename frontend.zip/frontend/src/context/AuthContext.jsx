import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { authService } from '../services/authService.js'

const AuthContext = createContext(null)

// El token se guarda solo en memoria hasta decidir el almacenamiento en la integración con el backend.
export function AuthProvider({ children }) {
  const [session, setSession] = useState({ user: null, token: null })

  const login = useCallback(async (email, password) => {
    const data = await authService.login(email, password)
    setSession({ user: data.user ?? { email }, token: data.access_token ?? data.token ?? null })
  }, [])

  const logout = useCallback(() => {
    setSession({ user: null, token: null })
  }, [])

  const value = useMemo(
    () => ({
      user: session.user,
      token: session.token,
      isAuthenticated: Boolean(session.token),
      login,
      logout,
    }),
    [session, login, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth debe usarse dentro de AuthProvider')
  return ctx
}
