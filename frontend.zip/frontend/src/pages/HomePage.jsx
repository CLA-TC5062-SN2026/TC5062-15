﻿import { Card } from '../components'
import { API_URL } from '../services/api.js'
import styles from './HomePage.module.css'

export default function HomePage() {
  return (
    <Card title="Audio2Score" subtitle="Transcripción de audio a partitura.">
      <p className={styles.muted}>
        API: <code>{API_URL}</code>
      </p>
    </Card>
  )
}
