export const API_URL = import.meta.env.VITE_API_URL

export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error?.message ?? body?.message ?? `Error ${status}`)
    this.status = status
    this.body = body
  }
}

export async function apiRequest(path, { method = 'GET', body, token, headers } = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      ...(body !== undefined && { 'Content-Type': 'application/json' }),
      ...(token && { Authorization: `Bearer ${token}` }),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })

  const data = response.status === 204 ? null : await response.json().catch(() => null)
  if (!response.ok) throw new ApiError(response.status, data)
  return data
}
