import { apiRequest } from './api.js'

export const authService = {
  register: (email, password) => apiRequest('/auth/register', { method: 'POST', body: { email, password } }),
  login: (email, password) => apiRequest('/auth/login', { method: 'POST', body: { email, password } }),
  me: (token) => apiRequest('/auth/me', { token }),
  logout: (token) => apiRequest('/auth/logout', { method: 'POST', token }),
}
