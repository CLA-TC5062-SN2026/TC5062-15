import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// CSS Modules se habilita por convención con archivos *.module.css.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173 },
})
